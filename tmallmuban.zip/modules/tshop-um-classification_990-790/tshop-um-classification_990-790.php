<?php function set($val,$info = 0,$csz = '-99'){ $zhi = $_MODULE[$val]; if($csz != '-99' && $zhi == ''){ $zhi = $csz; } if($info == 0){ return $zhi; }else{ echo $zhi; } }  function setwz($wz){ $wz = explode(',' ,set($wz)); return 'left:'.$wz[0].'px;top:'.$wz[1].'px;'; } function getStyle($type, $val, $setVal = ''){ if($val == ''){ return ''; } if($setVal == ''){ $style = $type.':'.$val.';'; }else{ $style = $type.':'.$setVal.';'; } return $style; }  function imgsize($size,$setsize='400'){ if($size == ''){$size = $setsize;} $imgsize = array(16,20,24,30,32,36,40,48,60,64,70,72,80,90,100,110,120,128,130,145,160,170,190,200,210,220,230,240,250,290,300,310,320,350,360,400,430,460,480,540,560,570,670);  if($size > $imgsize[count($imgsize)-1]){ return $imgsize[count($imgsize)-1]; }else{ for ($i = 0; $i < count($imgsize); $i++) { if($imgsize[$i] >= $size){ return $imgsize[$i]; $i = count($imgsize); } } } }function get_holiday_url(){return $_MODULE['jrbq'];}function torf($play_name,$module){ $is_display = explode('@_@',$module); $play = in_array($play_name,$is_display)? true : false; return $play; } function haveAttr($attr,$value,$other=''){ if ($value) { return $attr.':'.$value.$other; } } function setBackground($value,$tof,$str=''){ if ($value) { $bac='background'; return $tof ? "$bac: url($value)".$str : "$bac:$value".$str ; } } function get_nr($module,$icon,$ele,$class=''){ $nr_arr = explode($icon,$module); $nr_str =''; foreach ($nr_arr as $nr){ $nr_str = $nr_str."<$ele class='$class'>$nr</$ele>"; } return $nr_str; } function make_Arr($str,$icon){ $arr=explode($icon,$str); return $arr; }   function marb(){ return $_MODULE['mar-b'] ? 'margin-bottom:'.$_MODULE['mar-b'].'px;' : ''; } function color($color){ return $_MODULE[$color] ? 'color:'.$_MODULE[$color].';' : ''; } function jb($icon,$zdy,$size){ if($_MODULE["$zdy"]){ return "background:url($zdy) no-repeat;"; } else if($_MODULE["$icon"]){ $icon = $_MODULE["$icon"] ; return "background:url(../../assets/images/$size"."jb/$icon.png) no-repeat;"; } } function ws($num,$ws){ return number_format($num,$ws,'.',''); } function ewm($m='e-code'){ return $ec = $_MODULE[$m] =='tc' ? 'tc' : ''; } function jgbq(){ return $ec = $_MODULE['jg-class'] =='jgtc' ? 'jgtc' : ''; } function mb($m='dtmb'){ $tp = $_MODULE[$m]; return "../../assets/images/zz/$tp.gif"; } function bk(){ return $_MODULE['bk'] =='dt' ? 'dt' : ''; } function djs(){ return $_MODULE['djstx'] =='dtc' ? 'dtc' : ''; } function tof($play_name,$model='tof'){ $is_display = explode('@_@',$_MODULE[$model]); $play = in_array($play_name,$is_display)? true : false; return $play; } function jrbq($m='jrbq'){ $bq = $_MODULE["$m"] == 'zd' ? get_holiday_url() : $_MODULE["$m"]; return  "../../assets/images/cx/$bq.png"; } function bh($n,$m='bh'){ $height = explode(',',$_MODULE["$m"])[$n]; return $height ? "height:$height".'px;' :''; } function ys($m){ if($_MODULE["$m"]){ return "color:".$_MODULE["$m"].';'; } } function btlb($n,$m1='timgurl',$m2="mcolor1"){ $tb = explode(',',$_MODULE[$m1]); $re = ''; if($tb[$n]){ $re = setBackground($tb[$n],true,' no-repeat 50% 0;'); } else if($_MODULE[$m2]){ $re = setBackground($_MODULE[$m2],false,';'); } return $re; } function mr($m="purl"){ return $_MODULE[$m]; } function fm($n,$m="prurl"){ $url = explode(',',$_MODULE[$m]); if($url[$n]){ return $url[$n]; } else if($url[0]){ return $url[0];}}function jb1($icon,$zdy,$n,$size,$wh="jbsize"){ if($_MODULE["$zdy"]){ $i = explode(',',$_MODULE["$zdy"]); $src = "$i[$n]"; } else if($_MODULE["$icon"]){ $icon = $_MODULE["$icon"] ; $src = "../../assets/images/$size"."jb/$icon.png"; } $size = explode(',',$_MODULE[$wh]); $w = $size[0] ? "width="."$size[0]":''; $h = $size[1] ? "height="."$size[1]" :''; $jb = array(); $jb['src'] = $src ; $jb['w'] = $w ; $jb['h'] = $h ; return $jb ; } function barr($n=0,$m){ $arr = explode(',',$_MODULE["$m"]); return $arr[$n] ? "background:$arr[$n];" : ''; } function custom($m = 'custom'){ $arr = explode(',',$_MODULE[$m]); $num = $arr[0]-1; $arr[0] = $arr[0] ? "model$arr[0]" : ''; $arr1 = $arr[1]; $arr[1] = $arr1==='cfx' ? $arr[1] : 'zfx'; $arr[2] = $arr1==='cfx' ? ' '.$arr[0].'1' : ''; $arr[3] = $num; return $arr;}function skuImg($idList,$imgSize = '30'){  global $itemManager; $openItemDOList= $itemManager->queryByIds($idList,''); $skuLists = $itemManager->queryOpenSkuDOListByOpenItemDOList($openItemDOList);  foreach($skuLists as $skuList){  $urlArr [] =  $itemManager->getSkuPropertyPics($skuList,"$imgSize");}return $urlArr;}function getErcode($erId, $widthHeight = "90", $type = "1") { switch($type){ case 1: $code = 'type=ci&item_id='.$erId.'&v=1'; break; case 2: $code = 'v=1&type=bi&item_id='.$erId; break; case 3: $code = 'type=cs&shop_id='.$erId.'&v=1'; break; case 4: $code = 'v=1&type=bs&shop_id='.$erId; break; case 5: $code = 'type=we&we_id='.$erId.'&v=1'; break; default: $code = 'type=ci&item_id='.$erId.'&v=1'; } $imgsrc = 'http://gqrcode.alicdn.com/img?'.$code.'&w='.$widthHeight.'&h='.$widthHeight; return $imgsrc; }  function getFav($favText, $favItemid, $favData, $favClass = "qzzfav"){ global $uriManager; if($favData == 'shop'){ $sc_url = $uriManager->favoriteLink(); $sc_title = "����ղر�����"; }elseif($favData == 'item'){ $sc_url = "http://favorite.taobao.com/popup/add_collection.htm?id=".$favItemid."&itemtype=1&scjjc=1"; $sc_title = "����ղ��������"; } $sc = '<a class="J_TokenSign '.$favClass.'" title="'.$sc_title.'" href="'.$sc_url.'" target="_blank">'.$favText.'</a>'; return $sc; }  function getSizes(){ $tbSizes = array( 16,20,24,30,32,36,40,48,50,60,64,70,72,80,88,90,100,110,120,125,128,130,145,160,170,180,190,200,210,220,230,234, 240,250,270,290,300,310,315,320,336,350,360,400,430,460,468,480,490,540,560,570,580,600,640,670,720,728,760,960,970 ); return $tbSizes; } function getImg($img){ $arraySize = getSizes(); $newArray = array(); foreach($arraySize as $size){ if($size>=$img){ $newArray[] = $size; } } $itemPic = $img>970?"970":min($newArray); return $itemPic; } function discountPrice($item){ if($item->discountPrice || $item->discountPrice!=$item->price) { $discountPrice = number_format($item->discountPrice,3,".",""); }else{ $discountPrice = number_format($item->price,3,".",""); } return $discountPrice; } function getItems($ids, $categoryId, $keyword, $sortType = " ", $num = "20", $itemData = "1", $idsType= "itemForm") {global $itemManager, $uriManager, $rateManager; $arraySize = getSizes(); $itemsObj = array(); $ratesObj = array(); if($ids!=null && $itemData == 2){ if($idsType == 'itemRateForm'){ $itemRates = $rateManager->parse($ids); foreach($itemRates->keySet() as $id){ $itemsObj[] = $itemManager->queryById($id); $ratesObj[] = $itemRates->get($id); } }else{ $arrayIds = is_string($ids) ? explode(',', $ids) : (array) $ids; if($sortType == " "){ foreach($arrayIds as $id){ $itemsObj[] = $itemManager->queryById($id); } }else{ $itemsObj = $itemManager->queryByIds($arrayIds,$sortType); } } }elseif($categoryId!=null && $itemData == 3){ $jsonArray = json_decode($categoryId); foreach($jsonArray as $jsonObject){ $childIds = explode(",",$jsonObject->{childIds}); if($jsonObject->{childIds} != null){ foreach($childIds as $childId){ $items_xfl = $itemManager->queryByCategory($childId,$sortType,$num); foreach($items_xfl as $itemCate){ $itemsObj[] = $itemCate!=null ? $itemCate : ""; } } }else{ $items_dfl = $itemManager->queryByCategory($jsonObject->{rid},$sortType,$num); foreach($items_dfl as $itemCate){ $itemsObj[] = $itemCate!=null ? $itemCate : ""; } } } }elseif($keyword!=null && $itemData == 4||$itemData == 1){ $kw = $itemData==1?" ":$keyword; $kwObj = $itemManager->queryByKeyword($kw,$sortType,$num);$newType = str_replace('__','','_'.$sortType); $newObj = $sortType==" "?$kwObj:array_reverse($itemManager->queryByKeyword($kw,$newType,$num)); $delObj = array_unique(array_merge($kwObj,$newObj)); $itemsObj = array_merge($delObj,$delObj,$delObj,$delObj,$delObj);}  $skuLists = $itemsObj!=null ? $itemManager->queryOpenSkuDOListByOpenItemDOList($itemsObj) : ""; $itemData = $itemsObj!=null ? $itemData : "5"; $items = array(); if($itemData != 5 || $itemsObj!=null){$idArr=array();foreach ($itemsObj as $key => $item) { if($key<$num&&!in_array($item->id,$idArr)){$idArr[]=$item->id; if($item->exist){$qzz['url'] = $uriManager->detailURI($item); foreach($arraySize as $imgSize){ $qzz['pic'.$imgSize] = $item->getPicUrl($imgSize); } $qzz['title'] = $item->title; $qzz['price'] = $item->price; $qzz['discountPrice'] = discountPrice($item); $qzz['zhekou'] = number_format(str_replace(',','',discountPrice($item))/str_replace(',','',$item->price),2)*10; $qzz['soldCount'] = $item->soldCount; $qzz['collectedCount'] = $item->collectedCount; $qzz['id'] = $item->id; $qzz['commentCount'] = $item->commentCount;$qzz['pj'] =$uriManager->rateURI();$qzz['itemCategoryId'] = $item->itemCategoryId; $qzz['skuList'] = $skuLists[$key]; foreach($arraySize as $imgSize){ $qzz['skuPics'.$imgSize] = $itemManager->getSkuPropertyPics($skuLists[$key],$imgSize,$imgSize); } $qzz['rateList'] = $ratesObj[$key]!=null?$ratesObj[$key]:""; } }else{break;} $items['idA'][] = $qzz['id']; $items[] = $qzz; }} if($itemData == 5|| $items == null) { $imgUrl = array( "http://img02.taobaocdn.com/imgextra/i2/34251258/TB2Dc8mcVXXXXbHXpXXXXXXXXXX_!!34251258.jpg", "http://img02.taobaocdn.com/imgextra/i2/34251258/TB2Dc8mcVXXXXbHXpXXXXXXXXXX_!!34251258.jpg" ); for ($i = 0; $i < $num; $i++){ $mtRand = mt_rand(0,(count($imgUrl)-1)); $qzz['url'] = "http://www.taobao.com/?id=www.qiaozhezou.com";foreach($arraySize as $imgSize){$qzz['pic'.$imgSize]=$imgUrl[$mtRand]."_".$imgSize."x".$imgSize.".jpg"; }$qzz['title']="��������δ���ӣ��������Ͻǵı༭��ťѡ���������ı���";$qzz['price']="0.00";$qzz['discountPrice']="00.00";$qzz['zhekou']=number_format(398.98/598.00,2)*10;$qzz['soldCount']="0";$qzz['collectedCount']="0";$qzz['id']="1".$i;$qzz['itemCategoryId']="2".$i;$qzz['no']=true;$items[]=$qzz;}$items[]='';} return $items;}?>
<!--common_separator_local-->
<?php
/**
 ���ݹ���
 1.PHPҳ������ֻ�ܰ���һ����Ԫ�أ����������ǩԪ�أ��Ƽ�"div"Ԫ�أ�
 2.��Ԫ���ඨ�������class="tb-module tshop-um tshop-um-classification_990-790"��class���Կ�����������Ҫ����ѡ�������壩
 3.Ԫ��class����ֵ��ֹ��"tb-"��"J_T"�ַ���ͷ,��[tb-module, J_TWidget, J_CartPluginTrigger, J_TokenSign]����
 4.��ֹʹ��<style>��ǩ��Ԫ�أ�
 5.��ֹʹ��<script>��ǩ��Ԫ�أ�
 6.��ֹʹ��<link>��ǩ��Ԫ�أ�
 7.��ֹʹ�ñ�ǩ��Ԫ�أ���id����
 8.����ʹ��Ԫ������style����
 */
?>
<div class="tb-module tshop-um tshop-um-classification_990-790" style="<?=haveAttr('margin-bottom',$_MODULE['mar-b'],'px;')?>">
    <?php if(set('html') != '') {
        echo set('html');
    } else{
    function getCategorys($json,$categoryData = "1"){ global $shopCategoryManager, $uriManager; if(!empty($json)&&$categoryData == 2){ $allShopCategory = json_decode($json); }elseif($categoryData == 1){ $allShopCategory = $shopCategoryManager->queryAll(); } $categorys = array(); foreach($allShopCategory as $jsonObject){ if(!empty($json)&&$categoryData == 2){ $shopCategory =  $shopCategoryManager->queryById($jsonObject->{rid}); }elseif($categoryData == 1){ $shopCategory =  $jsonObject; } $category = array(); $category['parent']['url'] = $uriManager->shopCategoryURI($shopCategory); $category['parent']['name'] = $shopCategory->name; $category['parent']['id'] = $shopCategory->id;  if(!empty($json)&&$categoryData == 2){ $subCategories  = explode(",",$jsonObject->{childIds}); }elseif($categoryData == 1){ $subCategories  = $shopCategoryManager-> querySubCategories($shopCategory->id); } foreach($subCategories  as $childId){ if(!empty($json)&&$categoryData == 2){ $shopCategory = $shopCategoryManager->queryById($childId); }elseif($categoryData == 1){ $shopCategory =  $childId; } if($childId!=null){ $qzz['url'] = $uriManager->shopCategoryURI($shopCategory); $qzz['name'] =$shopCategory->name;$qzz['id']=$shopCategory->id;$category['child'][]=$qzz;}}$categorys[]=$category;}return $categorys; }
    function fl(){//990-790����--�ؼ�������
            for($i=1;$i<9;$i++){
                $bname[] = $_MODULE["b-name$i"];
                $burl[] = $_MODULE["b-url$i"];
                $sname[] = explode('|',$_MODULE["s-name$i"]);
                $surl[] = explode('|',$_MODULE["s-url$i"]);
            }
            $arr = array();
            for($i=0;$i<8;$i++){
                if (!$bname[$i]||!$burl[$i]) {
                    break;
                } else {
                    $arr[$i]['parent']['name'] = $bname[$i];
                    $arr[$i]['parent']['url'] = $burl[$i];
                    for ($j=0;$j<count($sname[$i]);$j++){
                        if (!$sname[$i]||!$surl[$i]) {
                            continue;
                        } else {
                            $arr[$i]['child'][$j]['name'] = $sname[$i][$j];
                            $arr[$i]['child'][$j]['url'] = $surl[$i][$j];
                        }
                    }
                }
            }
            return $arr  ;
        }
        if (torf('btl',$_MODULE['tof'])) {?>
    <div class="tb">
        <??>
        <div class="bt"><i></i> <span><?=$_MODULE['bt']?></span></div>

        <?php if (torf('ss',$_MODULE['tof'])) {?>
        <form class="ss" name="SearchForm" action="http://shop<?=$_shop->id?>.taobao.com" method="get" target="_blank">
            <input name="userId" value="" type="hidden">
            <input name="shopId" value="<?=$_shop->id?>" type="hidden">
            <input name="view_type" value="" type="hidden">
            <input name="order_type" value="" type="hidden">
            <input name="search" value="y" type="hidden">
            <input type="text" value="<?=$_MODULE['gjz']?>" name="keyword">
            <button class="tj"></button>
        </form>
        <?}?>
        <ul class="gz">
            <?php if (torf('rq',$_MODULE['tof'])) {?>
                <li><a href="<?=$uriManager->searchURI().'&orderType=ceofp_desc&v=1'?>">������</a></li>
            <?php } if (torf('xl',$_MODULE['tof'])) {?>
                <li class="xl bq">
                    <a href="<?=$uriManager->searchURI().'&orderType=hotsell_desc&v=1' ?>">
                        <?php if (torf('dt',$_MODULE['tof']) && torf('hot',$_MODULE['tof'])){?><i></i> <?}?><span>������</span>
                    </a>
                </li>
            <?php } if (torf('xp',$_MODULE['tof'])) {?>
                <li class="xp bq">
                    <a href="<?=$uriManager->searchURI().'&orderType=newOn_desc&v=1' ?>">
                        <?php if (torf('dt',$_MODULE['tof']) && torf('new',$_MODULE['tof'])){?><i></i> <?}?><span>����Ʒ</span>
                    </a>
                </li>
            <?php } if (torf('jg',$_MODULE['tof'])) {?>
                <li><a href="<?=$uriManager->searchURI().'&orderType=price_asc&v=1' ?>">���۸�</a></li>
            <?php } if (torf('sc',$_MODULE['tof'])) {?>
                <li><a href="<?=$uriManager->searchURI().'&orderType=hotkeep_desc&v=1' ?>">���ղ�</a></li>
            <?}?>
        </ul>
    </div>
        <?}?>
    <?php
        $flWrap= $_MODULE['cmethod'] =='gjc' ? fl() : getCategorys($_MODULE['sdfl'],$_MODULE['cmethod']);//ȡ����������
        $num = min($_MODULE['group'],count($flWrap));//������������ڹ涨�ĺͲ�ѯ����ȡ��Сֵ
        $_MODULE['column'];//���� - һ�м��������
        $_MODULE['class'];// ����-������м���С����
        $nul=ceil($num/$_MODULE['column']);//���� - ����
        switch ($_MODULE['cmethod']){
            case 'zd':
                break;
            case 'sd':
                break;
            case 'gjc':
                for ($i=1;$i<9;$i++){
                    if ($_MODULE["b-name$i"]) {
                        $flWrap[1][$i] = $_MODULE["b-name$i"];
                        $flWrap[2][$i] = explode('|',$_MODULE["s-name$i"]);
                    }
                    else{
                        break;
                    }
                }
                break;
        }
    if($_MODULE['cmodel']=='hx'){?>
    <ul class="section1">
        <?
            for ($cl1=0;$cl1<$num;$cl1++){
        ?>

        <li class="line">
            <a class="line-bt" href="<?=$flWrap[$cl1]['parent']['url']?>"><?=$flWrap[$cl1]['parent']['name']?></a>
            <div class="xfl">
                <?
                foreach ($flWrap[$cl1]['child'] as $it){
                    ?>
                <a href="<?=$it['url']?>"><?=$it['name']?></a>
                <?}?>
            </div>
        </li>
        <?}?>
    </ul>
    <?} if($_MODULE['cmodel']=='zx1'){?>
 <ul class="section2">
        <?php
for($i=0;$i<$nul;$i++){
    ?>
            <li class="line" style="z-index: <?=99-$i?>;height:30px;">
                <?php
                for ($j=0;$j <$_MODULE['column']&&(($i*$_MODULE['column']+$j)<$num);$j++){
        ?>
                    <div class="dfl <?='Popup'.$i.$j?>">
                        <p class="bt"><a href="<?=$flWrap[$i*$_MODULE['column']+$j]['parent']['url']?>"><?=$flWrap[$i*$_MODULE['column']+$j]['parent']['name']?></a></p>

                        <? if (count($flWrap[$i*$_MODULE['column']+$j]['child'])) {?>
                        <i></i>
                        <?}?>
                        <ul class="J_TWidget hidden xfl" data-widget-type="Popup" data-widget-config="{
                              'trigger':'.<?='Popup'.$i.$j?>',
                              'align':{
                                      'node':'.<?='Popup'.$i.$j?>',
                                      'offset':[0,30],
                                      'points':['tl','tl']
                                      }
                }">
                        <?php foreach ($flWrap[$i*$_MODULE['column']+$j]['child'] as $it){?>
                            <li><a href="<?=$it['url']?>"><?=$it['name']?></a></li>
                        <?}?>
                        </ul>
                    </div>
                <?php}?>
            </li>
        <?php}?>
    </ul>
   <?} if($_MODULE['cmodel']=='zx2'){?>
   <ul class="J_TWidget section2" data-widget-type="Accordion" data-widget-config="{
      'triggerType':'mouse','triggerCls':'at',
      'panelCls': 'ap'
        }">
    <?php

for($i=0;$i<$nul;$i++){
?>
        <li class="line">
            <?php
        for ($nli=0;$nli<$_MODULE['column']&&(($i*$_MODULE['column']+$nli)<$num+1);$nli++){
            if (!$flWrap[$i*$_MODULE['column']+$nli]) {
                break;
            }else {
    ?>
                <div class="dfl">
                    <p class="bt at"><a href="<?=$flWrap[$i*$_MODULE['column']+$nli]['parent']['url']?>"><?=$flWrap[$i*$_MODULE['column']+$nli]['parent']['name']?></a></p>
                    <? if (count($flWrap[$i*$_MODULE['column']+$nli]['child'])) {?>
                        <i></i>
                    <?}?>
                    <ul class="xfl ap" style="display: none;">
                        <?php foreach ($flWrap[$i*$_MODULE['column']+$nli]['child'] as $it){?>
                            <li><a href="<?=$it['url']?>"><?=$it['name']?></a></li>
                        <?}?>
                    </ul>
                </div>
            <?php}}?>
        </li>
    <?php}?>
</ul>
<?}}?>
</div>
