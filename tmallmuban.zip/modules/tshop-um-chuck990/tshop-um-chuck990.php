<?php function set($val,$info = 0,$csz = '-99'){ $zhi = $_MODULE[$val]; if($csz != '-99' && $zhi == ''){ $zhi = $csz; } if($info == 0){ return $zhi; }else{ echo $zhi; } }  function setwz($wz){ $wz = explode(',' ,set($wz)); return 'left:'.$wz[0].'px;top:'.$wz[1].'px;'; } function getStyle($type, $val, $setVal = ''){ if($val == ''){ return ''; } if($setVal == ''){ $style = $type.':'.$val.';'; }else{ $style = $type.':'.$setVal.';'; } return $style; }  function imgsize($size,$setsize='400'){ if($size == ''){$size = $setsize;} $imgsize = array(16,20,24,30,32,36,40,48,60,64,70,72,80,90,100,110,120,128,130,145,160,170,190,200,210,220,230,240,250,290,300,310,320,350,360,400,430,460,480,540,560,570,670);  if($size > $imgsize[count($imgsize)-1]){ return $imgsize[count($imgsize)-1]; }else{ for ($i = 0; $i < count($imgsize); $i++) { if($imgsize[$i] >= $size){ return $imgsize[$i]; $i = count($imgsize); } } } }function get_holiday_url(){return $_MODULE['jrbq'];}function torf($play_name,$module){ $is_display = explode('@_@',$module); $play = in_array($play_name,$is_display)? true : false; return $play; } function haveAttr($attr,$value,$other=''){ if ($value) { return $attr.':'.$value.$other; } } function setBackground($value,$tof,$str=''){ if ($value) { $bac='background'; return $tof ? "$bac: url($value)".$str : "$bac:$value".$str ; } } function get_nr($module,$icon,$ele,$class=''){ $nr_arr = explode($icon,$module); $nr_str =''; foreach ($nr_arr as $nr){ $nr_str = $nr_str."<$ele class='$class'>$nr</$ele>"; } return $nr_str; } function make_Arr($str,$icon){ $arr=explode($icon,$str); return $arr; }   function marb(){ return $_MODULE['mar-b'] ? 'margin-bottom:'.$_MODULE['mar-b'].'px;' : ''; } function color($color){ return $_MODULE[$color] ? 'color:'.$_MODULE[$color].';' : ''; } function jb($icon,$zdy,$size){ if($_MODULE["$zdy"]){ return "background:url($zdy) no-repeat;"; } else if($_MODULE["$icon"]){ $icon = $_MODULE["$icon"] ; return "background:url(../../assets/images/$size"."jb/$icon.png) no-repeat;"; } } function ws($num,$ws){ return number_format($num,$ws,'.',''); } function ewm($m='e-code'){ return $ec = $_MODULE[$m] =='tc' ? 'tc' : ''; } function jgbq(){ return $ec = $_MODULE['jg-class'] =='jgtc' ? 'jgtc' : ''; } function mb($m='dtmb'){ $tp = $_MODULE[$m]; return "../../assets/images/zz/$tp.gif"; } function bk(){ return $_MODULE['bk'] =='dt' ? 'dt' : ''; } function djs(){ return $_MODULE['djstx'] =='dtc' ? 'dtc' : ''; } function tof($play_name,$model='tof'){ $is_display = explode('@_@',$_MODULE[$model]); $play = in_array($play_name,$is_display)? true : false; return $play; } function jrbq($m='jrbq'){ $bq = $_MODULE["$m"] == 'zd' ? get_holiday_url() : $_MODULE["$m"]; return  "../../assets/images/cx/$bq.png"; } function bh($n,$m='bh'){ $height = explode(',',$_MODULE["$m"])[$n]; return $height ? "height:$height".'px;' :''; } function ys($m){ if($_MODULE["$m"]){ return "color:".$_MODULE["$m"].';'; } } function btlb($n,$m1='timgurl',$m2="mcolor1"){ $tb = explode(',',$_MODULE[$m1]); $re = ''; if($tb[$n]){ $re = setBackground($tb[$n],true,' no-repeat 50% 0;'); } else if($_MODULE[$m2]){ $re = setBackground($_MODULE[$m2],false,';'); } return $re; } function mr($m="purl"){ return $_MODULE[$m]; } function fm($n,$m="prurl"){ $url = explode(',',$_MODULE[$m]); if($url[$n]){ return $url[$n]; } else if($url[0]){ return $url[0];}}function jb1($icon,$zdy,$n,$size,$wh="jbsize"){ if($_MODULE["$zdy"]){ $i = explode(',',$_MODULE["$zdy"]); $src = "$i[$n]"; } else if($_MODULE["$icon"]){ $icon = $_MODULE["$icon"] ; $src = "../../assets/images/$size"."jb/$icon.png"; } $size = explode(',',$_MODULE[$wh]); $w = $size[0] ? "width="."$size[0]":''; $h = $size[1] ? "height="."$size[1]" :''; $jb = array(); $jb['src'] = $src ; $jb['w'] = $w ; $jb['h'] = $h ; return $jb ; } function barr($n=0,$m){ $arr = explode(',',$_MODULE["$m"]); return $arr[$n] ? "background:$arr[$n];" : ''; } function custom($m = 'custom'){ $arr = explode(',',$_MODULE[$m]); $num = $arr[0]-1; $arr[0] = $arr[0] ? "model$arr[0]" : ''; $arr1 = $arr[1]; $arr[1] = $arr1==='cfx' ? $arr[1] : 'zfx'; $arr[2] = $arr1==='cfx' ? ' '.$arr[0].'1' : ''; $arr[3] = $num; return $arr;}function skuImg($idList,$imgSize = '30'){  global $itemManager; $openItemDOList= $itemManager->queryByIds($idList,''); $skuLists = $itemManager->queryOpenSkuDOListByOpenItemDOList($openItemDOList);  foreach($skuLists as $skuList){  $urlArr [] =  $itemManager->getSkuPropertyPics($skuList,"$imgSize");}return $urlArr;}function getErcode($erId, $widthHeight = "90", $type = "1") { switch($type){ case 1: $code = 'type=ci&item_id='.$erId.'&v=1'; break; case 2: $code = 'v=1&type=bi&item_id='.$erId; break; case 3: $code = 'type=cs&shop_id='.$erId.'&v=1'; break; case 4: $code = 'v=1&type=bs&shop_id='.$erId; break; case 5: $code = 'type=we&we_id='.$erId.'&v=1'; break; default: $code = 'type=ci&item_id='.$erId.'&v=1'; } $imgsrc = 'http://gqrcode.alicdn.com/img?'.$code.'&w='.$widthHeight.'&h='.$widthHeight; return $imgsrc; }  function getFav($favText, $favItemid, $favData, $favClass = "qzzfav"){ global $uriManager; if($favData == 'shop'){ $sc_url = $uriManager->favoriteLink(); $sc_title = "����ղر�����"; }elseif($favData == 'item'){ $sc_url = "http://favorite.taobao.com/popup/add_collection.htm?id=".$favItemid."&itemtype=1&scjjc=1"; $sc_title = "����ղ��������"; } $sc = '<a class="J_TokenSign '.$favClass.'" title="'.$sc_title.'" href="'.$sc_url.'" target="_blank">'.$favText.'</a>'; return $sc; }  function getSizes(){ $tbSizes = array( 16,20,24,30,32,36,40,48,50,60,64,70,72,80,88,90,100,110,120,125,128,130,145,160,170,180,190,200,210,220,230,234, 240,250,270,290,300,310,315,320,336,350,360,400,430,460,468,480,490,540,560,570,580,600,640,670,720,728,760,960,970 ); return $tbSizes; } function getImg($img){ $arraySize = getSizes(); $newArray = array(); foreach($arraySize as $size){ if($size>=$img){ $newArray[] = $size; } } $itemPic = $img>970?"970":min($newArray); return $itemPic; } function discountPrice($item){ if($item->discountPrice || $item->discountPrice!=$item->price) { $discountPrice = number_format($item->discountPrice,3,".",""); }else{ $discountPrice = number_format($item->price,3,".",""); } return $discountPrice; } function getItems($ids, $categoryId, $keyword, $sortType = " ", $num = "20", $itemData = "1", $idsType= "itemForm") {global $itemManager, $uriManager, $rateManager; $arraySize = getSizes(); $itemsObj = array(); $ratesObj = array(); if($ids!=null && $itemData == 2){ if($idsType == 'itemRateForm'){ $itemRates = $rateManager->parse($ids); foreach($itemRates->keySet() as $id){ $itemsObj[] = $itemManager->queryById($id); $ratesObj[] = $itemRates->get($id); } }else{ $arrayIds = is_string($ids) ? explode(',', $ids) : (array) $ids; if($sortType == " "){ foreach($arrayIds as $id){ $itemsObj[] = $itemManager->queryById($id); } }else{ $itemsObj = $itemManager->queryByIds($arrayIds,$sortType); } } }elseif($categoryId!=null && $itemData == 3){ $jsonArray = json_decode($categoryId); foreach($jsonArray as $jsonObject){ $childIds = explode(",",$jsonObject->{childIds}); if($jsonObject->{childIds} != null){ foreach($childIds as $childId){ $items_xfl = $itemManager->queryByCategory($childId,$sortType,$num); foreach($items_xfl as $itemCate){ $itemsObj[] = $itemCate!=null ? $itemCate : ""; } } }else{ $items_dfl = $itemManager->queryByCategory($jsonObject->{rid},$sortType,$num); foreach($items_dfl as $itemCate){ $itemsObj[] = $itemCate!=null ? $itemCate : ""; } } } }elseif($keyword!=null && $itemData == 4||$itemData == 1){ $kw = $itemData==1?" ":$keyword; $kwObj = $itemManager->queryByKeyword($kw,$sortType,$num);$newType = str_replace('__','','_'.$sortType); $newObj = $sortType==" "?$kwObj:array_reverse($itemManager->queryByKeyword($kw,$newType,$num)); $delObj = array_unique(array_merge($kwObj,$newObj)); $itemsObj = array_merge($delObj,$delObj,$delObj,$delObj,$delObj);}  $skuLists = $itemsObj!=null ? $itemManager->queryOpenSkuDOListByOpenItemDOList($itemsObj) : ""; $itemData = $itemsObj!=null ? $itemData : "5"; $items = array(); if($itemData != 5 || $itemsObj!=null){$idArr=array();foreach ($itemsObj as $key => $item) { if($key<$num&&!in_array($item->id,$idArr)){$idArr[]=$item->id; if($item->exist){$qzz['url'] = $uriManager->detailURI($item); foreach($arraySize as $imgSize){ $qzz['pic'.$imgSize] = $item->getPicUrl($imgSize); } $qzz['title'] = $item->title; $qzz['price'] = $item->price; $qzz['discountPrice'] = discountPrice($item); $qzz['zhekou'] = number_format(str_replace(',','',discountPrice($item))/str_replace(',','',$item->price),2)*10; $qzz['soldCount'] = $item->soldCount; $qzz['collectedCount'] = $item->collectedCount; $qzz['id'] = $item->id; $qzz['commentCount'] = $item->commentCount;$qzz['pj'] =$uriManager->rateURI();$qzz['itemCategoryId'] = $item->itemCategoryId; $qzz['skuList'] = $skuLists[$key]; foreach($arraySize as $imgSize){ $qzz['skuPics'.$imgSize] = $itemManager->getSkuPropertyPics($skuLists[$key],$imgSize,$imgSize); } $qzz['rateList'] = $ratesObj[$key]!=null?$ratesObj[$key]:""; } }else{break;} $items['idA'][] = $qzz['id']; $items[] = $qzz; }} if($itemData == 5|| $items == null) { $imgUrl = array( "http://img02.taobaocdn.com/imgextra/i2/34251258/TB2Dc8mcVXXXXbHXpXXXXXXXXXX_!!34251258.jpg", "http://img02.taobaocdn.com/imgextra/i2/34251258/TB2Dc8mcVXXXXbHXpXXXXXXXXXX_!!34251258.jpg" ); for ($i = 0; $i < $num; $i++){ $mtRand = mt_rand(0,(count($imgUrl)-1)); $qzz['url'] = "http://www.taobao.com/?id=www.qiaozhezou.com";foreach($arraySize as $imgSize){$qzz['pic'.$imgSize]=$imgUrl[$mtRand]."_".$imgSize."x".$imgSize.".jpg"; }$qzz['title']="��������δ���ӣ��������Ͻǵı༭��ťѡ���������ı���";$qzz['price']="0.00";$qzz['discountPrice']="00.00";$qzz['zhekou']=number_format(398.98/598.00,2)*10;$qzz['soldCount']="0";$qzz['collectedCount']="0";$qzz['id']="1".$i;$qzz['itemCategoryId']="2".$i;$qzz['no']=true;$items[]=$qzz;}$items[]='';} return $items;}?>
<!--common_separator_local-->
<?php$mb = $_MODULE['btl'] == 't3'|| $_MODULE['btl'] == 't4' ? 'background:#fff;':'';$mcolor = explode(',',$_MODULE['mcolor']); ?>
<div class="tb-module tshop-um tshop-um-chuck990"  style="<?=marb(),setBackground($mcolor[0],false,';'),$mb?>">
<?php if(set('html') != '') {echo set('html');}else{
function jb2($icon,$zdy,$wh="jbsize"){ if($_MODULE["$zdy"]){ $srcArr = array(); $i = explode('|',$_MODULE["$zdy"]); for ($j = 0;$j<count($i);$j++){ $srcArr[$j] = explode(',',$i[$j]); } $src = $srcArr; $tof = true; } else if($_MODULE["$icon"]){ $icon = $_MODULE["$icon"] ; $src = "../../assets/images/990"."jb/$icon.png"; $tof = false; } $size = explode(',',$_MODULE[$wh]); $w = $size[0] ? "width="."$size[0]":''; $h = $size[1] ? "height="."$size[1]" :''; $jb = array(); $jb['src'] = $src ; $jb['w'] = $w ; $jb['h'] = $h ; $jb['tof'] =$tof; return $jb ; }
    $color = explode(',',$_MODULE['color']);
$primg = tof('primg');$ys = tof('ys');$isjb = tof('jb');$ewm1 = $_MODULE['ewm'];$yj = tof('yj');$ptitle = tof('ptitle');$xl = tof('xl');$pj = tof('pj');$jg = tof('jg');$sc = tof('sc');$ewm = tof('ewm');$gwc = tof('gwc');
$jb = $isjb ? jb2('jb', 'jb-url', 0) : '';$w = $jb['h'];$h = $jb['w'];$jbtof = $jb['tof'];
$mbk = $_MODULE['bk'];
$dtbk = $mbk ? "<div class=\"bk $mbk\"><i class=\"i1\"></i><i class=\"i2\"></i><i class=\"i3\"></i><i class=\"i4\"></i></div>" : '';
$dtmb = $_MODULE['dtmb'] ? "<img src=\"" . mb() . "\" alt=\"\" class=\"fmtp" . ' ' . $_MODULE['mbtx'] . "\">" : '';
$color1 = $color[0];$color2 = $color[1];$color3 =$color[2];$color4 = $color[3];$color5 = $color[4];$color6 =
    $color[5];$color7 = $color[6];
$jrbq = $_MODULE['jrbq'] !='zd' ? jrbq() : $_MODULE['jrzdy'];
$jrbq = $_MODULE['jrbq'] != '35' ? "<img src=\"$jrbq\" alt=\"\" class=\"jr-jb\">" : '';
switch (custom()[0]) {
    case 'model5':$ecsize = 45;break;case "model1":$ecsize = 100;break;case 'model2':$ecsize = 80;break;default:$ecsize = 60;}
function imgS($m = 'custom'){$arr = explode(',',$_MODULE[$m]);return $arr[count($arr)-1] ;}
$bbbj = setBackground($mcolor[1], false, ';');
$titleArr = explode(',', $_MODULE['fqbt']);$lineN = explode(',', $_MODULE['custom'])[0] * 1 + 1;$all = $_MODULE['number'];
$xtp = array(array(417, 252, 162, 118, 100), array(10, 7, 5, 3, 3), array(13, 7, 3, 14, 5));$ysArr = array();$custom = custom();$size = imgS();
function kpfm(){if(!preg_match('/\|/',$_MODULE['prurl'])){$fm = $_MODULE['prurl'];$tof = false;} else{$fm = explode('|',$_MODULE['prurl']);
for($i=0;$i<count($fm);$i++){$fm[$i] = explode(',',$fm[$i]);}$tof = true;}$kpfm[0] = $fm ;$kpfm[1] = $tof;return $kpfm;}?>
    <div class="section1 J_TWidget box" data-widget-type="Tabs" data-widget-config="{
'effect':'<?=$_MODULE["fqgd"]?>','triggerType' : 'click','activeTriggerCls':'click','autoplay':<?=$_MODULE["fqqh"]?>}">
    <?php $bt = explode('|',$_MODULE['td']);if ($_MODULE['btl']){switch ($_MODULE['btl']){case 't1':?>
                    <a href="<?=$uriManager->searchURI()?>" class="t1 title" style="<?=btlb(0)?><?=bh(0);?>" target="_blank">
                        <h2><?=explode(',',$bt[0])[0]?></h2><h4><?=explode(',',$bt[0])[1]?></h4>
                    </a><?php break;case 't2':?>
                <a href="<?=$uriManager->searchURI()?>" class="t2 title" style="<?=btlb(1);?><?=bh(1);?>"  target="_blank">
                    <p class="yw"><?=explode(',',$bt[1])[0]?></p><p class="zw"><?=explode(',',$bt[1])[1]?></p>
                </a><?php break;case 't3': ?>
                <a href="<?=$uriManager->searchURI()?>" class="t3 title" style="<?=btlb(2);?><?=bh(2);?>" target="_blank">
                    <?=$bt[2]?>
                </a><?php break; case 't4':?>
                <a href="<?=$uriManager->searchURI()?>" class="t4 title" style="<?=btlb(3);?><?=bh(3);?>" target="_blank">
                    <h4><?$t4=explode(',',explode('|',$bt[3])[0]);echo $t4[0];?></h4><h5><?=$t4[1]?></h5>
                </a>
            <?}}if (tof('fq')){ ?>
            <ul class="option ks-switchable-nav" style="<?='width:'.(count($titleArr)*160-30).'px'?>">
                <?php for($i=0;$i<count($titleArr);$i++){switch ($i){case 0:$cln='click';break;case count($titleArr)-1:
        $cln = 'last';break;default:$cln = '';} ?><li class="<?=$cln?> focu"><?=$titleArr[$i]?></li><?}?></ul><?}
        $zsh = tof('ys') ? 50:0;$pth = tof('ptitle') ? 28:0;$xph = tof('xl')||tof('pj') ? 16:0;$segh = tof('sc')||tof('ewm')||tof('gwc') ? 20:0;
        switch ($custom[0]){
            case 'model1':$jgh = tof('jg')||tof('yj') ? 32:0;$sizeh =!!$custom[2]? 670:480;break;
            case 'model2' :$jgh = tof('jg')||tof('yj') ? 28:0;$sizeh =!!$custom[2]? 460:310;break;
            case 'model3' :$jgh = tof('jg')||tof('yj') ? 20:0;$sizeh =!!$custom[2]? 310:220;break;
            case 'model4' :$jgh = tof('jg')||tof('yj') ? 20:0;$sizeh =!!$custom[2]? 250:170;break;
            default :$jgh = tof('jg')||tof('yj') ? 20:0;$sizeh =!!$custom[2]? 220:150;
        }
        $mb10=tof('yj')||tof('jg')||tof('xl')||tof('pj')||tof('sc')||tof('ewm')||tof('gwc')||tof('ys')||tof('ptitle') ? 10:0;
        $mainh = $sizeh + $zsh + $jgh + $pth + $xph + $segh + $mb10;
        $ht = "height : $mainh.px"; ?>
        <div class="relative" style="<?=$ht?>">
            <ul class="main ks-switchable-content" style="position: relative;<?=setBackground($mcolor[0],false,';')?>">
                <?php$prurlArr = explode('|',$_MODULE['prurl']);foreach ($prurlArr as $item){
                    $fmArr[] = explode(',',$item);}$kwArr = explode(',',$_MODULE['dkey']);
                for( $tn=0;$tn<count($titleArr);$tn++){ $lic = $tn==0 ? 'all click' : 'all';?>
            <li class="<?=$lic?>">
                <?
                    $om = $_MODULE["op-m$tn"];
                    $items0 = getItems($_MODULE['bbs'.($tn+1)],$_MODULE['lms'.($tn+1)],$kwArr[$tn],$_MODULE['sort'.
                    ($tn+1)],$lineN, $om);if(!$items0[0]){
                        $om0 = '5';$items0 = getItems($_MODULE['bbs'.($tn+1)],$_MODULE['lms'.($tn+1)],$kwArr[$tn],$_MODULE['sort'. ($tn+1)],$lineN, $om);;
                    }$simg1 = skuImg($items0['idA']);$count1 = array();for($i=0;$i<count($simg1);$i++){
                        $count1[$i] = count(array_filter($simg1[$i]));}$ysArr[$tn] = $count1;$xfkn[$tn] = count($items0)-1;?>
                            <ul class="model <?= $custom[0], $custom[2] ?> ">
                                <? for ($ln = 0; $ln < count($items0)-1; $ln++) {
                                    $clast = ($ln + 1) === $lineN ? "last" : '';
                                    $qhjt = $ysArr[$tn][$ln] > $xtp[1][$custom[3]] ? "<i class=\"left\"></i><i
                                        class=\"right\"></i>" : '';
                                    $lipb = tof('yj')||tof('jg')||tof('xl')||tof('pj')||tof('sc')||tof('ewm')||tof('gwc')||tof('ys')||tof('ptitle') ? '':'padding-bottom:0';?>
<li class="li hover <?= $clast.' '.$_MODULE['hovercss'] ?>" style="<?=$bbbj,$lipb?>">
        <a class="tp-bf <?= $custom[1] ?>" href="<?=$items0[$ln]['url']?>" target="_blank" title="����鿴" >
            <i class="zt" style="background: url(<?=$items0[$ln]["pic$size"];?>)
                    no-repeat <?=$_MODULE['zswz']?>"></i>
            <?=$dtbk; if($ewm1){?>
                <img src="<?=getErcode($items0[$ln]['id'],$ecsize,2)?>" alt=""class="ewm <?=$ewm1?>" >
            <?php}$src = $jbtof ? $jb['src'][$tn][$ln] : $jb['src'];
            echo $isjb && $src ? "<img src=\"$src\" alt=\"\" class=\"jb\" $w $h >" : '';echo $jrbq;echo $dtmb ;if ($primg && $fmArr[$tn][$ln]){?>
                <img src="<?=$fmArr[$tn][$ln]?>" alt="" class="fmtp <?= $_MODULE['fmdh'] ?>"><!--����ͼƬ--><?}?>
        </a>
        <div class="down" >
            <?if ($ys){?><!-- && $count1[$ln]-->
                <div class="zs J_TWidget" data-widget-type="Carousel"
                     data-widget-config="{'navCls':'xfk','activeTriggerCls':'selected','contentCls':'xbb',
'effect': 'scrollx','easing': 'easeBoth','interval':5,'steps':<?= $xtp[1][$custom[3]] ?>,'viewSize': [<?= $xtp[0][$custom[3]] ?>],
'circular': false,'autoplay':false,'prevBtnCls': 'left','nextBtnCls': 'right','disableBtnCls': 'disable','duration':0.4}">
                    <div class="gd" style="<?= 'width:'.$xtp[0][$custom[3]].'px' ?>">
                        <ul class="xbb">
                <? for
                ($lii = 0; $lii < $ysArr[$tn][$ln]; $lii++) {$cli = ($lii + 1) % $xtp[1][$custom[3]] == 0 ? "class='last'" : '';
            ?><li <?= $cli ?>><img src="<?= $simg1[$ln][$lii] ?>" alt="" width="30" height="30"></li><? } ?></ul></div><?=$qhjt?></div>
            <?}?>
            <div class="jg" ><?if($jg){?>
                    <span class="xj" style="<?= $color7 ?>">  ��<?= ws($items0[$ln]['discountPrice'], $_MODULE['jg']) ?></span>
                <?}if ($yj){?><del class="yj" style="<?= $color6 ?>">��<?= ws($items0[$ln]['price'], $_MODULE['yj']) ?></del><?}?>
            </div><?if ($ptitle){?><p class="name" style="<?=$color1?>"><?=$items0[$ln]['title']?></p><?}if( tof('xl')|| tof('pj')){?>
            <div class="sc-pl"><?if($xl){?>
                    <span class="zw"  style="<?=$color3?> ">������</span><a href="<?=$items0[$ln]['url']?>" class="sz" style="<?=$color2?>" target="_blank"><?=$items0[$ln]['soldCount']?></a>
                <?}if($xl&&$pj){?><i></i><?}if($pj){?>
                    <span class="zw" style="<?=$color5?>">����</span><a href="<?=$items0[$ln]['url']?>" class="sz" style="<?=$color4?>" target="_blank"><?=$items0[$ln]['commentCount']?></a>
                <?}?></div><?}if( tof('sc')|| tof('ewm')||tof('gwc')){?><div class="icon"><?if($sc){?>
                    <a class="mark" href="http://favorite.taobao.com/popup/add_collection.htm?id=<?= $items0[$ln]['id'] ?>&itemtype=1&scjjc=1" target="_blank" ></a>
                <?}if($ewm){?>
                    <i class="ewm" style="<?$ml = !$sc? 'margin-left:0;':'';echo $ml;?>"><img src="<?=getErcode($items0[$ln]['id'],20,2)?>" alt=""></i>
                <?}if($gwc){?>
                    <a class="gwc J_CartPluginTrigger" href="<?=$items0[$ln]['url']?>" target="_blank" title="���빺�ﳵ"></a>
                <?}?></div><? } ?></div></li><? } ?></ul></li><?php}}?></ul></div></div></div>