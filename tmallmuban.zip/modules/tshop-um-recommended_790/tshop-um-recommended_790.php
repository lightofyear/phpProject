<?php function set($val,$info = 0,$csz = '-99'){ $zhi = $_MODULE[$val]; if($csz != '-99' && $zhi == ''){ $zhi = $csz; } if($info == 0){ return $zhi; }else{ echo $zhi; } }  function setwz($wz){ $wz = explode(',' ,set($wz)); return 'left:'.$wz[0].'px;top:'.$wz[1].'px;'; } function getStyle($type, $val, $setVal = ''){ if($val == ''){ return ''; } if($setVal == ''){ $style = $type.':'.$val.';'; }else{ $style = $type.':'.$setVal.';'; } return $style; }  function imgsize($size,$setsize='400'){ if($size == ''){$size = $setsize;} $imgsize = array(16,20,24,30,32,36,40,48,60,64,70,72,80,90,100,110,120,128,130,145,160,170,190,200,210,220,230,240,250,290,300,310,320,350,360,400,430,460,480,540,560,570,670);  if($size > $imgsize[count($imgsize)-1]){ return $imgsize[count($imgsize)-1]; }else{ for ($i = 0; $i < count($imgsize); $i++) { if($imgsize[$i] >= $size){ return $imgsize[$i]; $i = count($imgsize); } } } }function get_holiday_url(){return $_MODULE['jrbq'];}function torf($play_name,$module){ $is_display = explode('@_@',$module); $play = in_array($play_name,$is_display)? true : false; return $play; } function haveAttr($attr,$value,$other=''){ if ($value) { return $attr.':'.$value.$other; } } function setBackground($value,$tof,$str=''){ if ($value) { $bac='background'; return $tof ? "$bac: url($value)".$str : "$bac:$value".$str ; } } function get_nr($module,$icon,$ele,$class=''){ $nr_arr = explode($icon,$module); $nr_str =''; foreach ($nr_arr as $nr){ $nr_str = $nr_str."<$ele class='$class'>$nr</$ele>"; } return $nr_str; } function make_Arr($str,$icon){ $arr=explode($icon,$str); return $arr; }   function marb(){ return $_MODULE['mar-b'] ? 'margin-bottom:'.$_MODULE['mar-b'].'px;' : ''; } function color($color){ return $_MODULE[$color] ? 'color:'.$_MODULE[$color].';' : ''; } function jb($icon,$zdy,$size){ if($_MODULE["$zdy"]){ return "background:url($zdy) no-repeat;"; } else if($_MODULE["$icon"]){ $icon = $_MODULE["$icon"] ; return "background:url(../../assets/images/$size"."jb/$icon.png) no-repeat;"; } } function ws($num,$ws){ return number_format($num,$ws,'.',''); } function ewm($m='e-code'){ return $ec = $_MODULE[$m] =='tc' ? 'tc' : ''; } function jgbq(){ return $ec = $_MODULE['jg-class'] =='jgtc' ? 'jgtc' : ''; } function mb($m='dtmb'){ $tp = $_MODULE[$m]; return "../../assets/images/zz/$tp.gif"; } function bk(){ return $_MODULE['bk'] =='dt' ? 'dt' : ''; } function djs(){ return $_MODULE['djstx'] =='dtc' ? 'dtc' : ''; } function tof($play_name,$model='tof'){ $is_display = explode('@_@',$_MODULE[$model]); $play = in_array($play_name,$is_display)? true : false; return $play; } function jrbq($m='jrbq'){ $bq = $_MODULE["$m"] == 'zd' ? get_holiday_url() : $_MODULE["$m"]; return  "../../assets/images/cx/$bq.png"; } function bh($n,$m='bh'){ $height = explode(',',$_MODULE["$m"])[$n]; return $height ? "height:$height".'px;' :''; } function ys($m){ if($_MODULE["$m"]){ return "color:".$_MODULE["$m"].';'; } } function btlb($n,$m1='timgurl',$m2="mcolor1"){ $tb = explode(',',$_MODULE[$m1]); $re = ''; if($tb[$n]){ $re = setBackground($tb[$n],true,' no-repeat 50% 0;'); } else if($_MODULE[$m2]){ $re = setBackground($_MODULE[$m2],false,';'); } return $re; } function mr($m="purl"){ return $_MODULE[$m]; } function fm($n,$m="prurl"){ $url = explode(',',$_MODULE[$m]); if($url[$n]){ return $url[$n]; } else if($url[0]){ return $url[0];}}function jb1($icon,$zdy,$n,$size,$wh="jbsize"){ if($_MODULE["$zdy"]){ $i = explode(',',$_MODULE["$zdy"]); $src = "$i[$n]"; } else if($_MODULE["$icon"]){ $icon = $_MODULE["$icon"] ; $src = "../../assets/images/$size"."jb/$icon.png"; } $size = explode(',',$_MODULE[$wh]); $w = $size[0] ? "width="."$size[0]":''; $h = $size[1] ? "height="."$size[1]" :''; $jb = array(); $jb['src'] = $src ; $jb['w'] = $w ; $jb['h'] = $h ; return $jb ; } function barr($n=0,$m){ $arr = explode(',',$_MODULE["$m"]); return $arr[$n] ? "background:$arr[$n];" : ''; } function custom($m = 'custom'){ $arr = explode(',',$_MODULE[$m]); $num = $arr[0]-1; $arr[0] = $arr[0] ? "model$arr[0]" : ''; $arr1 = $arr[1]; $arr[1] = $arr1==='cfx' ? $arr[1] : 'zfx'; $arr[2] = $arr1==='cfx' ? ' '.$arr[0].'1' : ''; $arr[3] = $num; return $arr;}function skuImg($idList,$imgSize = '30'){  global $itemManager; $openItemDOList= $itemManager->queryByIds($idList,''); $skuLists = $itemManager->queryOpenSkuDOListByOpenItemDOList($openItemDOList);  foreach($skuLists as $skuList){  $urlArr [] =  $itemManager->getSkuPropertyPics($skuList,"$imgSize");}return $urlArr;}function getErcode($erId, $widthHeight = "90", $type = "1") { switch($type){ case 1: $code = 'type=ci&item_id='.$erId.'&v=1'; break; case 2: $code = 'v=1&type=bi&item_id='.$erId; break; case 3: $code = 'type=cs&shop_id='.$erId.'&v=1'; break; case 4: $code = 'v=1&type=bs&shop_id='.$erId; break; case 5: $code = 'type=we&we_id='.$erId.'&v=1'; break; default: $code = 'type=ci&item_id='.$erId.'&v=1'; } $imgsrc = 'http://gqrcode.alicdn.com/img?'.$code.'&w='.$widthHeight.'&h='.$widthHeight; return $imgsrc; }  function getFav($favText, $favItemid, $favData, $favClass = "qzzfav"){ global $uriManager; if($favData == 'shop'){ $sc_url = $uriManager->favoriteLink(); $sc_title = "����ղر�����"; }elseif($favData == 'item'){ $sc_url = "http://favorite.taobao.com/popup/add_collection.htm?id=".$favItemid."&itemtype=1&scjjc=1"; $sc_title = "����ղ��������"; } $sc = '<a class="J_TokenSign '.$favClass.'" title="'.$sc_title.'" href="'.$sc_url.'" target="_blank">'.$favText.'</a>'; return $sc; }  function getSizes(){ $tbSizes = array( 16,20,24,30,32,36,40,48,50,60,64,70,72,80,88,90,100,110,120,125,128,130,145,160,170,180,190,200,210,220,230,234, 240,250,270,290,300,310,315,320,336,350,360,400,430,460,468,480,490,540,560,570,580,600,640,670,720,728,760,960,970 ); return $tbSizes; } function getImg($img){ $arraySize = getSizes(); $newArray = array(); foreach($arraySize as $size){ if($size>=$img){ $newArray[] = $size; } } $itemPic = $img>970?"970":min($newArray); return $itemPic; } function discountPrice($item){ if($item->discountPrice || $item->discountPrice!=$item->price) { $discountPrice = number_format($item->discountPrice,3,".",""); }else{ $discountPrice = number_format($item->price,3,".",""); } return $discountPrice; } function getItems($ids, $categoryId, $keyword, $sortType = " ", $num = "20", $itemData = "1", $idsType= "itemForm") {global $itemManager, $uriManager, $rateManager; $arraySize = getSizes(); $itemsObj = array(); $ratesObj = array(); if($ids!=null && $itemData == 2){ if($idsType == 'itemRateForm'){ $itemRates = $rateManager->parse($ids); foreach($itemRates->keySet() as $id){ $itemsObj[] = $itemManager->queryById($id); $ratesObj[] = $itemRates->get($id); } }else{ $arrayIds = is_string($ids) ? explode(',', $ids) : (array) $ids; if($sortType == " "){ foreach($arrayIds as $id){ $itemsObj[] = $itemManager->queryById($id); } }else{ $itemsObj = $itemManager->queryByIds($arrayIds,$sortType); } } }elseif($categoryId!=null && $itemData == 3){ $jsonArray = json_decode($categoryId); foreach($jsonArray as $jsonObject){ $childIds = explode(",",$jsonObject->{childIds}); if($jsonObject->{childIds} != null){ foreach($childIds as $childId){ $items_xfl = $itemManager->queryByCategory($childId,$sortType,$num); foreach($items_xfl as $itemCate){ $itemsObj[] = $itemCate!=null ? $itemCate : ""; } } }else{ $items_dfl = $itemManager->queryByCategory($jsonObject->{rid},$sortType,$num); foreach($items_dfl as $itemCate){ $itemsObj[] = $itemCate!=null ? $itemCate : ""; } } } }elseif($keyword!=null && $itemData == 4||$itemData == 1){ $kw = $itemData==1?" ":$keyword; $kwObj = $itemManager->queryByKeyword($kw,$sortType,$num);$newType = str_replace('__','','_'.$sortType); $newObj = $sortType==" "?$kwObj:array_reverse($itemManager->queryByKeyword($kw,$newType,$num)); $delObj = array_unique(array_merge($kwObj,$newObj)); $itemsObj = array_merge($delObj,$delObj,$delObj,$delObj,$delObj);}  $skuLists = $itemsObj!=null ? $itemManager->queryOpenSkuDOListByOpenItemDOList($itemsObj) : ""; $itemData = $itemsObj!=null ? $itemData : "5"; $items = array(); if($itemData != 5 || $itemsObj!=null){$idArr=array();foreach ($itemsObj as $key => $item) { if($key<$num&&!in_array($item->id,$idArr)){$idArr[]=$item->id; if($item->exist){$qzz['url'] = $uriManager->detailURI($item); foreach($arraySize as $imgSize){ $qzz['pic'.$imgSize] = $item->getPicUrl($imgSize); } $qzz['title'] = $item->title; $qzz['price'] = $item->price; $qzz['discountPrice'] = discountPrice($item); $qzz['zhekou'] = number_format(str_replace(',','',discountPrice($item))/str_replace(',','',$item->price),2)*10; $qzz['soldCount'] = $item->soldCount; $qzz['collectedCount'] = $item->collectedCount; $qzz['id'] = $item->id; $qzz['commentCount'] = $item->commentCount;$qzz['pj'] =$uriManager->rateURI();$qzz['itemCategoryId'] = $item->itemCategoryId; $qzz['skuList'] = $skuLists[$key]; foreach($arraySize as $imgSize){ $qzz['skuPics'.$imgSize] = $itemManager->getSkuPropertyPics($skuLists[$key],$imgSize,$imgSize); } $qzz['rateList'] = $ratesObj[$key]!=null?$ratesObj[$key]:""; } }else{break;} $items['idA'][] = $qzz['id']; $items[] = $qzz; }} if($itemData == 5|| $items == null) { $imgUrl = array( "http://img02.taobaocdn.com/imgextra/i2/34251258/TB2Dc8mcVXXXXbHXpXXXXXXXXXX_!!34251258.jpg", "http://img02.taobaocdn.com/imgextra/i2/34251258/TB2Dc8mcVXXXXbHXpXXXXXXXXXX_!!34251258.jpg" ); for ($i = 0; $i < $num; $i++){ $mtRand = mt_rand(0,(count($imgUrl)-1)); $qzz['url'] = "http://www.taobao.com/?id=www.qiaozhezou.com";foreach($arraySize as $imgSize){$qzz['pic'.$imgSize]=$imgUrl[$mtRand]."_".$imgSize."x".$imgSize.".jpg"; }$qzz['title']="��������δ���ӣ��������Ͻǵı༭��ťѡ���������ı���";$qzz['price']="0.00";$qzz['discountPrice']="00.00";$qzz['zhekou']=number_format(398.98/598.00,2)*10;$qzz['soldCount']="0";$qzz['collectedCount']="0";$qzz['id']="1".$i;$qzz['itemCategoryId']="2".$i;$qzz['no']=true;$items[]=$qzz;}$items[]='';} return $items;}?>
<!--common_separator_local-->
<?php$mb = $_MODULE['btl'] == 't3'|| $_MODULE['btl'] == 't4' ? 'background:#fff;':''; ?>
<div class="tb-module tshop-um tshop-um-recommended_790"  style="<?=marb(),setBackground($_MODULE['mcolor2'],false,';'),$mb?>">
<?php if(set('html') != '') {echo set('html');} else{function getT($m='time',$y ='djsy'){
$djsy ='������������ʱ';$tArr = explode('|',$_MODULE[$m]);$yArr = explode('|',$_MODULE[$y]);
for ($i = 0;$i<count($tArr);$i++){$yArr[$i] = $yArr[$i] ? $yArr[$i] :$djsy;}$arr[0] = $tArr;$arr[1] = $yArr;
return $arr;}$lineN = explode(',',$_MODULE['custom'])[0]*1+1;$all = $_MODULE['pnum'];$line = ceil($all/$lineN);
$boxb = $_MODULE['btl'] == 't2' || $_MODULE['btl'] == 't3' || $_MODULE['btl'] == 't4' ? 'background:#fff;':'';
$htzt ='';$htzt = !$htzt ? $_MODULE['purl'] : $htzt;
switch (custom()[0]) {case 'model4':$ecsize = 45;break;case "model1":$ecsize = 80;break;default:$ecsize = 60;}
        function imgS($m = 'custom'){
            $arr = explode(',',$_MODULE[$m]);return $arr[count($arr)-1] ;}?>
        <div class="box" >
            <?php
            $custom = custom();
            if ($_MODULE['btl']){
                switch ($_MODULE['btl']){
                    case 't1':
                    ?>
                    <a href="<?=explode(',',$_MODULE['turl'])[0]?>" class="t1" style="<?=btlb(0)?><?=bh(0);?>" target="_blank">
                        <h2><?=$_MODULE['t1d']?></h2>
                        <h4><?=$_MODULE['t1x']?></h4>
                    </a>
                    <?php break;case 't2':?>
                    <a href="<?=explode(',',$_MODULE['turl'])[1]?>" class="t2" style="<?=btlb(1);?><?=bh(1);?>" target="_blank">
                        <p class="yw"><?=$_MODULE['t2d']?></p>
                    </a>
                    <?php break;case 't3': ?>
                    <a href="<?=explode(',',$_MODULE['turl'])[2]?>" class="t3" style="<?=btlb(2);?><?=bh(2);?>" target="_blank">
                        <?=$_MODULE['t3']?>
                    </a>
                    <?php break; case 't4':?>
                    <a href="<?=explode(',',$_MODULE['turl'])[3]?>" class="t4" style="<?=btlb(3);?><?=bh(3);?>" target="_blank">
                        <h4><?=$_MODULE['t4d']?></h4>
                        <h5><?=$_MODULE['t4x']?></h5>
                    </a>
                <?}}
            for($l =0;$l<$line;$l++){
                $ln = $all - $l * $lineN > $lineN ? $lineN : $all - $l * $lineN;
                $hjj=$_MODULE['hjj'] ? $_MODULE['hjj']:10;
                $mar = $l !== $line-1 ?  "margin-bottom:".$hjj."px;":'';
                ?>
                <?
                $modle = $_MODULE['op-m'];
                $items = getItems($_MODULE['bbs'],$_MODULE['lms'],$_MODULE['dkey'],$_MODULE['bb0type1'],$_MODULE['pnum'],$modle);
                if (!$items[0]) {
                    $modle = '5';
                    $items = getItems($_MODULE['bbs'],$_MODULE['lms'],$_MODULE['dkey'],$_MODULE['bb0type1'],$_MODULE['pnum'],$modle);
                }
                $simg = skuImg($items['idA'],'30');
                $count = array();
for($inum=0;$inum<$line;$inum++){for($inl=0;$inl<$lineN;$inl++){$cn = count($simg[$lineN*$inum+$inl]);
foreach ($simg[$lineN*$inum+$inl] as $it){$cn = !$it ? $cn-1 : $cn;}$count[$inum][$inl] = $cn;}}
                ?>
                <ul class="<?=$custom[0],$custom[2]?> model">
<?for ($i=0;$i<$ln;$i++){ $ni = $i+$l*$lineN;
                    if ($items[$ni]['no']) {if (mr($ni)) {$ztUrl = mr($ni);} else {$ztUrl = $items[$ni]["pic".imgS()];
}} else {$ztUrl =  $items[$ni]["pic".imgS()];}$cl = $i+1 === $lineN ? 'last': '';$djs = getT(); ?>
                        <li class="<?=$_MODULE['hovercss']?> hover <?=$cl?> J_TWidget" style="<?=barr(0,'mc3'),$mar?>" data-widget-type="Countdown"  data-widget-config="{
'endTime': '<?=$djs[0][$i]?>','interval': 1000,'timeRunCls': '.ks-countdown-run','timeUnitCls':{
'd': '.ks-d','h': '.ks-h','m': '.ks-m','s': '.ks-s','i': '.ks-i'},'minDigit': 1,'timeEndCls': '.ks-countdown-end'}">
<a class="tp-bf <?=$custom[1]?>"  href="<?=$items[$ni]['url']?>" target="_blank" title="�鿴����" >
    <i title="�������" class="zt" style="<?=setBackground($ztUrl,true," no-repeat".$_MODULE['bacwz'])?>"></i>
    <!--��Ч�߿�-->
    <?if($_MODULE['bk']){?>
        <div class="txbk1 <?=$_MODULE['bk']?>"><i class="i1"></i><i class="i2"></i><i class="i3"></i><i class="i4"></i></div>
    <?}?>
    <? $jb=jb1('jb','jb-url',$i,'790');if(tof('jb')){?>
        <img src="<?=$jb['src']?>" <?=$jb['w'].' '.$jb['h']?> class="jb" >
    <?}?>
    <?if($_MODULE['jrbq']!='35'){?>
        <img src="<?= $_MODULE['jrbq']!='zd' ? jrbq() : $_MODULE['jrzdy'];?>" class="jr-jb">
    <?}?>
    <?if($_MODULE['ewm']){?>
        <img class="ewm <?=$_MODULE['ewm']?>" src="<?=getErcode($items[$ni]['id'],
            $ecsize,2)?>" width="<?=$ecsize?>" height="<?=$ecsize?>">
    <?}if($_MODULE['djszs']&&$djs[0][$i]){?>
        <?; if($custom[3]===0){?>
            <p class="djs <?=$_MODULE['djszs']?>" ><?=$djs[1][$i]?>:
                <span class="ks-d"></span><span>��</span><span class="ks-h"></span><span>ʱ</span><span
                        class="ks-m"></span><span>��</span><span class="ks-s"></span><span>��</span></p>
        <?}else{?>
<div class="djs <?=$_MODULE['djszs']?>"><p><?=$djs[1][$i]?>:</p><p>
<span class="ks-d"></span><span>��</span><span class="ks-h"></span>
        <span>ʱ</span><span class="ks-m"></span><span>��</span>
        <span class="ks-s"></span><span >��</span></p></div>
<?}}if($_MODULE['dtmb']){?><img src="<?=mb()?>" alt="" class="fmtp <?=$_MODULE['mbtx']?>">
<?php} if(tof('primg') && fm($i) ){?><img src="<?=fm($ni)?>" alt="" class="fmtp <?=$_MODULE['fmdh']?>"><?}?>
</a>

<?php if(tof('ys')){?><?
$maxArr = array(8,5,4,3);$marArr = array(13,12,6,5);$max =$maxArr[$custom[3]] ;$width = ($max -1)*(30+$marArr[$custom[3]])+30;
$hs = floor($count[$l][$i]/$max);$bs = $count[$l][$i]/$max == $hs ? 0 : 1;
$other = $count[$l][$i]/$max == $hs ? 0 : ($count[$l][$i] - $max*$hs-$bs)*(30+$marArr[$custom[3]])+30;
$wul = $hs*$width + $other; ?>
<div class="zs J_TWidget" data-widget-type="Carousel" data-widget-config="{'navCls':'xfk','activeTriggerCls':'selected',
'contentCls':'xbb','effect': 'scrollx','easing': 'easeBoth','interval':5,'steps':<?=$max?>,'viewSize': [<?=$width?>],
'circular': false,'autoplay':false,'prevBtnCls': 'go-left','nextBtnCls': 'go-right','disableBtnCls': 'disable','duration':0.4}">
                        <? if ($count[$l][$i]) { ?>
<div class="lb" style="display: inline-block;width: <?=$width.'px;'?>"><ul class="xbb" style="width: <?=$wul.'px;'?>">
        <?for ($lb=0;$lb<$count[$l][$i];$lb++){
            if(($lb+1)%$max===0 || $lb === ($count[$l][$i] -1)){$lcs = 'class="last"';}
            else{$lcs = '';}
            ?>
            <li <?=$lcs;?>><img src="<?=$simg[$ni][$lb]?>"></li>
        <?}?></ul></div>
<?if($max<$count[$l][$i]){?>
    <i class="go-left"></i><i class="go-right"></i>
<?}}?></div><?}?>
<?php if(tof('jg') || tof('yj')){?>
<div class="jg"><?php if(tof('jg')){?><span class="xj" style=" <?=color('color7')?>"><?=ws(1199.00,$_MODULE['jg'])?></span>
<?}?><?php if(tof('yj')){?><del class="yj"  style=" <?=color('color6')?>">��<?=ws(1900.00,$_MODULE['yj'])?></del>
<?}?></div><?}?><?php if(tof('ptitle')){?><p class="sm" style="<?=color('color1')?>"><?=$items[$ni]['title']?>
</p><?}?><?php if(tof('xl') || tof('pj')){?><div class="sc-pl"><?php if(tof('xl')){?>
<span class="hs" style="<?=color('color3')?>">������:</span><span class="hos"  style=" <?=color('color2')?>"><?=$items[$ni]['soldCount']?></span><?}?>
<?php if(tof('xl') && tof('pj')){?><i class="sx"></i><?}?><?php if(tof('pj')){?><a href="<?=$items[$ni]['url']?>" target="_blank">
<span class="hs"  style=" <?=color('color5')?>">����:</span><span class="hos"  style=" <?=color('colo4')?>"><?=$items[$ni]['commentCount']?></span></a><?}?></div><?}?>
<?php if(tof('sc')||tof('gwc')||tof('ewm')){?><div class="icon"><?php if(tof('sc')){?>
<a href="http://favorite.taobao.com/popup/add_collection.htm?id=<?= $items[$i]['id'] ?>&itemtype=1&scjjc=1"  class="mark"></a>
<?}?><?php if(tof('gwc')){$gml=tof('sc')? 'margin-left:30px;':'';?><a class="gwc J_CartPluginTrigger" target="_blank" title="���빺�ﳵ" href="<?=$items[$ni]['url']?>" style="<?=$gml?>"></a>
<?}?><?php if(tof('ewm')){$eml=tof('sc')||tof('gwc')? 'margin-left:30px;':'';?><i class="ewm"  style="<?=$eml?>"><img src="<?=getErcode($items[$ni]['id'],100,2)?>" alt="��ά��" title="ɨ�Ұ�-.-"></i>
<?}?></div><?}?></li><?}?></ul><?}?></div><?}?></div>