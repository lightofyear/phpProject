<?php function set($val,$info = 0,$csz = '-99'){ $zhi = $_MODULE[$val]; if($csz != '-99' && $zhi == ''){ $zhi = $csz; } if($info == 0){ return $zhi; }else{ echo $zhi; } }  function setwz($wz){ $wz = explode(',' ,set($wz)); return 'left:'.$wz[0].'px;top:'.$wz[1].'px;'; } function getStyle($type, $val, $setVal = ''){ if($val == ''){ return ''; } if($setVal == ''){ $style = $type.':'.$val.';'; }else{ $style = $type.':'.$setVal.';'; } return $style; }  function imgsize($size,$setsize='400'){ if($size == ''){$size = $setsize;} $imgsize = array(16,20,24,30,32,36,40,48,60,64,70,72,80,90,100,110,120,128,130,145,160,170,190,200,210,220,230,240,250,290,300,310,320,350,360,400,430,460,480,540,560,570,670);  if($size > $imgsize[count($imgsize)-1]){ return $imgsize[count($imgsize)-1]; }else{ for ($i = 0; $i < count($imgsize); $i++) { if($imgsize[$i] >= $size){ return $imgsize[$i]; $i = count($imgsize); } } } }function get_holiday_url(){return $_MODULE['jrbq'];}function torf($play_name,$module){ $is_display = explode('@_@',$module); $play = in_array($play_name,$is_display)? true : false; return $play; } function haveAttr($attr,$value,$other=''){ if ($value) { return $attr.':'.$value.$other; } } function setBackground($value,$tof,$str=''){ if ($value) { $bac='background'; return $tof ? "$bac: url($value)".$str : "$bac:$value".$str ; } } function get_nr($module,$icon,$ele,$class=''){ $nr_arr = explode($icon,$module); $nr_str =''; foreach ($nr_arr as $nr){ $nr_str = $nr_str."<$ele class='$class'>$nr</$ele>"; } return $nr_str; } function make_Arr($str,$icon){ $arr=explode($icon,$str); return $arr; }   function marb(){ return $_MODULE['mar-b'] ? 'margin-bottom:'.$_MODULE['mar-b'].'px;' : ''; } function color($color){ return $_MODULE[$color] ? 'color:'.$_MODULE[$color].';' : ''; } function jb($icon,$zdy,$size){ if($_MODULE["$zdy"]){ return "background:url($zdy) no-repeat;"; } else if($_MODULE["$icon"]){ $icon = $_MODULE["$icon"] ; return "background:url(../../assets/images/$size"."jb/$icon.png) no-repeat;"; } } function ws($num,$ws){ return number_format($num,$ws,'.',''); } function ewm($m='e-code'){ return $ec = $_MODULE[$m] =='tc' ? 'tc' : ''; } function jgbq(){ return $ec = $_MODULE['jg-class'] =='jgtc' ? 'jgtc' : ''; } function mb($m='dtmb'){ $tp = $_MODULE[$m]; return "../../assets/images/zz/$tp.gif"; } function bk(){ return $_MODULE['bk'] =='dt' ? 'dt' : ''; } function djs(){ return $_MODULE['djstx'] =='dtc' ? 'dtc' : ''; } function tof($play_name,$model='tof'){ $is_display = explode('@_@',$_MODULE[$model]); $play = in_array($play_name,$is_display)? true : false; return $play; } function jrbq($m='jrbq'){ $bq = $_MODULE["$m"] == 'zd' ? get_holiday_url() : $_MODULE["$m"]; return  "../../assets/images/cx/$bq.png"; } function bh($n,$m='bh'){ $height = explode(',',$_MODULE["$m"])[$n]; return $height ? "height:$height".'px;' :''; } function ys($m){ if($_MODULE["$m"]){ return "color:".$_MODULE["$m"].';'; } } function btlb($n,$m1='timgurl',$m2="mcolor1"){ $tb = explode(',',$_MODULE[$m1]); $re = ''; if($tb[$n]){ $re = setBackground($tb[$n],true,' no-repeat 50% 0;'); } else if($_MODULE[$m2]){ $re = setBackground($_MODULE[$m2],false,';'); } return $re; } function mr($m="purl"){ return $_MODULE[$m]; } function fm($n,$m="prurl"){ $url = explode(',',$_MODULE[$m]); if($url[$n]){ return $url[$n]; } else if($url[0]){ return $url[0];}}function jb1($icon,$zdy,$n,$size,$wh="jbsize"){ if($_MODULE["$zdy"]){ $i = explode(',',$_MODULE["$zdy"]); $src = "$i[$n]"; } else if($_MODULE["$icon"]){ $icon = $_MODULE["$icon"] ; $src = "../../assets/images/$size"."jb/$icon.png"; } $size = explode(',',$_MODULE[$wh]); $w = $size[0] ? "width="."$size[0]":''; $h = $size[1] ? "height="."$size[1]" :''; $jb = array(); $jb['src'] = $src ; $jb['w'] = $w ; $jb['h'] = $h ; return $jb ; } function barr($n=0,$m){ $arr = explode(',',$_MODULE["$m"]); return $arr[$n] ? "background:$arr[$n];" : ''; } function custom($m = 'custom'){ $arr = explode(',',$_MODULE[$m]); $num = $arr[0]-1; $arr[0] = $arr[0] ? "model$arr[0]" : ''; $arr1 = $arr[1]; $arr[1] = $arr1==='cfx' ? $arr[1] : 'zfx'; $arr[2] = $arr1==='cfx' ? ' '.$arr[0].'1' : ''; $arr[3] = $num; return $arr;}function skuImg($idList,$imgSize = '30'){  global $itemManager; $openItemDOList= $itemManager->queryByIds($idList,''); $skuLists = $itemManager->queryOpenSkuDOListByOpenItemDOList($openItemDOList);  foreach($skuLists as $skuList){  $urlArr [] =  $itemManager->getSkuPropertyPics($skuList,"$imgSize");}return $urlArr;}function getErcode($erId, $widthHeight = "90", $type = "1") { switch($type){ case 1: $code = 'type=ci&item_id='.$erId.'&v=1'; break; case 2: $code = 'v=1&type=bi&item_id='.$erId; break; case 3: $code = 'type=cs&shop_id='.$erId.'&v=1'; break; case 4: $code = 'v=1&type=bs&shop_id='.$erId; break; case 5: $code = 'type=we&we_id='.$erId.'&v=1'; break; default: $code = 'type=ci&item_id='.$erId.'&v=1'; } $imgsrc = 'http://gqrcode.alicdn.com/img?'.$code.'&w='.$widthHeight.'&h='.$widthHeight; return $imgsrc; }  function getFav($favText, $favItemid, $favData, $favClass = "qzzfav"){ global $uriManager; if($favData == 'shop'){ $sc_url = $uriManager->favoriteLink(); $sc_title = "����ղر�����"; }elseif($favData == 'item'){ $sc_url = "http://favorite.taobao.com/popup/add_collection.htm?id=".$favItemid."&itemtype=1&scjjc=1"; $sc_title = "����ղ��������"; } $sc = '<a class="J_TokenSign '.$favClass.'" title="'.$sc_title.'" href="'.$sc_url.'" target="_blank">'.$favText.'</a>'; return $sc; }  function getSizes(){ $tbSizes = array( 16,20,24,30,32,36,40,48,50,60,64,70,72,80,88,90,100,110,120,125,128,130,145,160,170,180,190,200,210,220,230,234, 240,250,270,290,300,310,315,320,336,350,360,400,430,460,468,480,490,540,560,570,580,600,640,670,720,728,760,960,970 ); return $tbSizes; } function getImg($img){ $arraySize = getSizes(); $newArray = array(); foreach($arraySize as $size){ if($size>=$img){ $newArray[] = $size; } } $itemPic = $img>970?"970":min($newArray); return $itemPic; } function discountPrice($item){ if($item->discountPrice || $item->discountPrice!=$item->price) { $discountPrice = number_format($item->discountPrice,3,".",""); }else{ $discountPrice = number_format($item->price,3,".",""); } return $discountPrice; } function getItems($ids, $categoryId, $keyword, $sortType = " ", $num = "20", $itemData = "1", $idsType= "itemForm") {global $itemManager, $uriManager, $rateManager; $arraySize = getSizes(); $itemsObj = array(); $ratesObj = array(); if($ids!=null && $itemData == 2){ if($idsType == 'itemRateForm'){ $itemRates = $rateManager->parse($ids); foreach($itemRates->keySet() as $id){ $itemsObj[] = $itemManager->queryById($id); $ratesObj[] = $itemRates->get($id); } }else{ $arrayIds = is_string($ids) ? explode(',', $ids) : (array) $ids; if($sortType == " "){ foreach($arrayIds as $id){ $itemsObj[] = $itemManager->queryById($id); } }else{ $itemsObj = $itemManager->queryByIds($arrayIds,$sortType); } } }elseif($categoryId!=null && $itemData == 3){ $jsonArray = json_decode($categoryId); foreach($jsonArray as $jsonObject){ $childIds = explode(",",$jsonObject->{childIds}); if($jsonObject->{childIds} != null){ foreach($childIds as $childId){ $items_xfl = $itemManager->queryByCategory($childId,$sortType,$num); foreach($items_xfl as $itemCate){ $itemsObj[] = $itemCate!=null ? $itemCate : ""; } } }else{ $items_dfl = $itemManager->queryByCategory($jsonObject->{rid},$sortType,$num); foreach($items_dfl as $itemCate){ $itemsObj[] = $itemCate!=null ? $itemCate : ""; } } } }elseif($keyword!=null && $itemData == 4||$itemData == 1){ $kw = $itemData==1?" ":$keyword; $kwObj = $itemManager->queryByKeyword($kw,$sortType,$num);$newType = str_replace('__','','_'.$sortType); $newObj = $sortType==" "?$kwObj:array_reverse($itemManager->queryByKeyword($kw,$newType,$num)); $delObj = array_unique(array_merge($kwObj,$newObj)); $itemsObj = array_merge($delObj,$delObj,$delObj,$delObj,$delObj);}  $skuLists = $itemsObj!=null ? $itemManager->queryOpenSkuDOListByOpenItemDOList($itemsObj) : ""; $itemData = $itemsObj!=null ? $itemData : "5"; $items = array(); if($itemData != 5 || $itemsObj!=null){$idArr=array();foreach ($itemsObj as $key => $item) { if($key<$num&&!in_array($item->id,$idArr)){$idArr[]=$item->id; if($item->exist){$qzz['url'] = $uriManager->detailURI($item); foreach($arraySize as $imgSize){ $qzz['pic'.$imgSize] = $item->getPicUrl($imgSize); } $qzz['title'] = $item->title; $qzz['price'] = $item->price; $qzz['discountPrice'] = discountPrice($item); $qzz['zhekou'] = number_format(str_replace(',','',discountPrice($item))/str_replace(',','',$item->price),2)*10; $qzz['soldCount'] = $item->soldCount; $qzz['collectedCount'] = $item->collectedCount; $qzz['id'] = $item->id; $qzz['commentCount'] = $item->commentCount;$qzz['pj'] =$uriManager->rateURI();$qzz['itemCategoryId'] = $item->itemCategoryId; $qzz['skuList'] = $skuLists[$key]; foreach($arraySize as $imgSize){ $qzz['skuPics'.$imgSize] = $itemManager->getSkuPropertyPics($skuLists[$key],$imgSize,$imgSize); } $qzz['rateList'] = $ratesObj[$key]!=null?$ratesObj[$key]:""; } }else{break;} $items['idA'][] = $qzz['id']; $items[] = $qzz; }} if($itemData == 5|| $items == null) { $imgUrl = array( "http://img02.taobaocdn.com/imgextra/i2/34251258/TB2Dc8mcVXXXXbHXpXXXXXXXXXX_!!34251258.jpg", "http://img02.taobaocdn.com/imgextra/i2/34251258/TB2Dc8mcVXXXXbHXpXXXXXXXXXX_!!34251258.jpg" ); for ($i = 0; $i < $num; $i++){ $mtRand = mt_rand(0,(count($imgUrl)-1)); $qzz['url'] = "http://www.taobao.com/?id=www.qiaozhezou.com";foreach($arraySize as $imgSize){$qzz['pic'.$imgSize]=$imgUrl[$mtRand]."_".$imgSize."x".$imgSize.".jpg"; }$qzz['title']="��������δ���ӣ��������Ͻǵı༭��ťѡ���������ı���";$qzz['price']="0.00";$qzz['discountPrice']="00.00";$qzz['zhekou']=number_format(398.98/598.00,2)*10;$qzz['soldCount']="0";$qzz['collectedCount']="0";$qzz['id']="1".$i;$qzz['itemCategoryId']="2".$i;$qzz['no']=true;$items[]=$qzz;}$items[]='';} return $items;}?>
<!--common_separator_local-->
<div class="tb-module tshop-um tshop-um-c-coupons" style="<?=(haveAttr('margin-bottom',$_MODULE['mar-b']).'px')?>;">
    <div class="sou">
<?php$soft = array();$mka = array('djs','yhq','zh');$mkb = array('yhq','djs','zh');$mkc = array('zh','djs','yhq');
switch ($_MODULE['go-soft']){case '1':$soft[0] = $mka;break;case '2':$soft[0] = $mkb;break;default :$soft[0] = $mkc;}
$module = $_MODULE['t-or-f'];function getPlay($play_name){global $module;return torf($play_name,$module);}

$is_display = array();$index =0;
foreach ($soft[0] as $i){$is_display[$index] = getPlay($i);$index ++;}$soft[1] = $is_display ;
$html_arr = array();//�洢html��Ԫ����?>
<?php foreach (explode('|',$_MODULE['cxy']) as $nr){$nrArr [] = $nr;}
$gd_nr = get_nr($_MODULE['subtitle'],'|','p','gd');//��ȡ������Ļ
$zm_color = haveAttr('color',$_MODULE['zm-color']);//��Ļ��ɫ
$cxy = $nrArr [0]; //������
$cxy_color = haveAttr('color',$nrArr [1]); //��������ɫ
$rksm = $nrArr [2]; //���������˵��
$rksm_color =haveAttr('color',$nrArr [3]); //���������˵����ɫ
$rksm_url = $_MODULE['active-url']; //���������˵��url��ַ
$active_url = setBackground($_MODULE['activeImg-url'],true); //�����ͼƬ��ַ
$gdcl = $_MODULE['show-type'] ? 'J_TWidget' : '' ;
$time =$nrArr [4];//����ʱʱ��
$config = "{
					 'endTime': '$time',
					 'interval': 1000,
					 'timeRunCls': '.ks-countdown-run',
					 'timeUnitCls':{
						'd': '.ks-d',
						'h': '.ks-h',
						'm': '.ks-m',
						's': '.ks-s',
						'i': '.ks-i'
					 },
					 'minDigit': 2,
					 'timeEndCls': '.ks-countdown-end'
				}";
$html_arr['djs'] = /*��ʱ����Ԫ*/ <<<EOF
    <div class="nor" style="$active_url">
            <div class="dgd $gdcl"  data-widget-type="Slide"
          data-widget-config="{'contentCls':'news-items','hasTriggers':false,'effect':'scrolly','easing':'easeOutStrong','interval':3,'duration':0.2}" style="$zm_color;">
          <div class="news-items">
            $gd_nr 
          </div>
                           
            </div>
            <div class="hd">
                <p class="lksm" style="$cxy_color">$cxy</p>
                <a href="$rksm_url" style="$rksm_color">$rksm</a>
            </div>
            <ul class="J_TWidget time"  data-widget-type="Countdown"  data-widget-config="$config">
                <li class="days ks-d">
                   
                </li>
                <li class="hours ks-h">
                    
                </li>
                <li class="minutes ks-m">
                   
                </li>
                <li class="seconds ks-s">
                    
                </li>
            </ul>
        </div>
EOF;
?>
<?php
$rmb = $_MODULE['rmb'] ? "<i>��</i>":'';//�ж�Ҫ��Ҫ����ҷ���
$value = make_Arr($_MODULE['value'],',');//�Żݽ��
$yw_nr = make_Arr($_MODULE['yw-nr'],',');//Ӣ��˵��
$zw_nr = make_Arr($_MODULE['zw-nr'],',');//����˵��
$mj_value = make_Arr($_MODULE['dec'],',');//�������
$a_url = make_Arr($_MODULE['a-url'],',');//���ַ
$yhq_bac = make_Arr($_MODULE['yhq-bac'],',');//�Ż�ȯ����
$yhq_num ='';//����ÿ���Ż�ȯ
$hover = $_MODULE['dec-mouseover'];//����ƶ�������
for($i=0;$i<$_MODULE['num-coupons']*1;$i++){
    $bac = setBackground($yhq_bac[$i],true,' no-repeat');
    $yhq_num = $yhq_num . "<li style=\"$bac\" class='li$i $hover'>
       <a href=\"$a_url[$i]\" target=\"_blank\">
           <div class=\"nr\">
               $rmb
               <span>$value[$i]</span>
               <div>
                   <p>$yw_nr[$i]</p>
                   <p>$zw_nr[$i]</p>
                   <p>��$mj_value[$i]Ԫ��ʹ��</p>
               </div>
           </div>
       </a>
   </li>";
}
$wul = $_MODULE['num-coupons']*1 > 1 ? ($_MODULE['num-coupons']*240+($_MODULE['num-coupons']*1-1)*10).'px' : '240px';
$html_arr['yhq'] = /*�Ż�ȯ��Ԫ*/ <<<EOF
    <div class="out">
        <ul class="yhq" style="width:$wul;">
            $yhq_num
        </ul> 
    </div>
EOF;
?><?php
//����ͼ
$piclong = $_MODULE['pic-area'];//��ͼͼƬ��ַ
$urllong = $_MODULE['pic-url'];//��ͼͼƬurl
//��ͼ1
$zt1 = explode('|',$_MODULE['dy1-url']);
$zt2 = explode('|',$_MODULE['dy2-url']);
$zt3 = explode('|',$_MODULE['dy3-url']);
$zt4 = explode('|',$_MODULE['dy4-url']);
$main1title = $_MODULE['det-title1'];//��ͼ1title
$main1nr = get_nr($_MODULE['det-article1'],"\r",'p','nr');//��ͼ1
$main1url = $zt1[0];//��ͼ1 ����
$main1bac = $zt1[1] ? setBackground($zt1[1],true) : setBackground($_MODULE['dy1-baccolor'],false);//��ȡ��Ԫ����
$main1anurl = $zt1[2];//��ͼ1 ��ťurl
$main1ani = $zt1[3];//��ͼ1 ��ťͼ
$isPlay1 = $_MODULE['det1-enter'] ? "<a href=\"$main1anurl\" target=\"_blank\" class=\"an\"><img src=\"$main1ani\" alt=\"\"></a>": '';

//��ͼ2
$main2title = $_MODULE['det-title2'];//��ͼ1title
$main2nr = get_nr($_MODULE['det-article2'],"\r",'p','nr');//��ͼ1
$main2bac = $zt2[1] ? setBackground($zt2[1],true) : setBackground($_MODULE['dy2-baccolor'],false);//��ȡ��Ԫ����
$main2url = $zt2[0];//��ͼ1 ����
$main2anurl = $zt2[2];//��ͼ1 ��ťurl
$main2ani = $zt2[3];//��ͼ1 ��ťͼ
$isPlay2 = $_MODULE['det2-enter'] ? "<a href=\"$main2anurl\" target=\"_blank\" class=\"an\"><img src=\"$main2ani\" alt=\"\"></a>": '';

//��ͼ3
$main3title = $_MODULE['det-title3'];//��ͼ1title
$main3nr = get_nr($_MODULE['det-article3'],"\r",'p','nr');//��ͼ1
$main3bac = $zt3[1] ? setBackground($zt3[1],true) : setBackground($_MODULE['dy3-baccolor'],false);//��ȡ��Ԫ����
$main3url = $zt3[0];//��ͼ1 ����
$main3anurl = $zt3[2];//��ͼ1 ��ťurl
$main3ani = $zt3[3];//��ͼ1 ��ťͼ
$isPlay3 = $_MODULE['det3-enter'] ? "<a href=\"$main3anurl\" target=\"_blank\" class=\"an\"><img src=\"$main3ani\" alt=\"\"></a>": '';

//��ͼ4
$main4title = $_MODULE['det-title4'];//��ͼ1title
$main4nr = get_nr($_MODULE['det-article4'],"\r",'p','nr');//��ͼ1
$main4bac = $zt4[1] ? setBackground($zt4[1],true) : setBackground($_MODULE['dy4-baccolor'],false);//��ȡ��Ԫ����
$main4url = $zt4[0];//��ͼ1 ����
$main4anurl = $zt4[2];//��ͼ1 ��ťurl
$main4ani = $zt4[3];//��ͼ1 ��ťͼ
$isPlay4 = $_MODULE['det4-enter'] ? "<a href=\"$main4anurl\" target=\"_blank\" class=\"an\"><img src=\"$main4ani\" alt=\"\"></a>": '';

//�᳤ͼ
$tran1 =$_MODULE['tran-cxy'];$tran2 =$_MODULE['tran-q'];$tran3 =$_MODULE['tran-je'];$tran4 =$_MODULE['tran-hb'];$tran5 =setBackground($_MODULE['tran-area'],true,';');$tran6 =$_MODULE['tran-url'];

$html_arr['zh']/*������ϵ�Ԫ*/ =<<<EOF
   <div class="cyzh">
            <a class="left" href="$urllong"  target="_blank">
                <img src="$piclong" alt="">
            </a>
            <div class="right">
                <ul class="up">
                    <li style="$main1bac;" class="li1">
                       <p class="bt">
                           $main1title
                        </p>
                            $main1nr
                        $isPlay1
                    </li>
                   <li style="$main2bac;" class="li2">
                       <p class="bt">
                           $main2title
                        </p>
                            $main2nr
                        $isPlay2
                    </li>
                    <li style="$main3bac;" class="li3">
                       <p class="bt">
                           $main3title
                        </p>
                        <a href="$main3anurl" class="liq" title="������" target="_blank">
                            <img src="assets/images/qiang.png" alt="��������" >
                        </a>
                            $main3nr
                        $isPlay3
                    </li>
                </ul>
                <div class="up-f"></div>
                <div class="down">
                    <a class="d-left" href="$tran6"  target="_blank" style="$tran5">
                        <img src="assets/images/hongbao.png" alt="">
                        <span class="cxy">$tran1</span>
                        <span class="msq">$tran2</span>
                        <span class="je">
                            <span class="sz">$tran3</span><span class="wz">$tran4</span>
                        </span>
                    </a>
                    <div class="d-right" style="$main4bac;">
                       <p class="bt">
                           $main4title
                        </p>
                            $main4nr
                        $isPlay4
                    </div>
                </div>
            </div>
        </div>
EOF;
?>
<?php $soft[2] = $html_arr;
if(set('html') != '') {echo set('html');}
else {for($i=0;$i<count($soft[1]);$i++){echo $soft[1][$i] ? $soft[2][$soft[0][$i]] :'';}}?>
    </div>
</div>
