<?php function set($val,$info = 0,$csz = '-99'){ $zhi = $_MODULE[$val]; if($csz != '-99' && $zhi == ''){ $zhi = $csz; } if($info == 0){ return $zhi; }else{ echo $zhi; } }  function setwz($wz){ $wz = explode(',' ,set($wz)); return 'left:'.$wz[0].'px;top:'.$wz[1].'px;'; } function getStyle($type, $val, $setVal = ''){ if($val == ''){ return ''; } if($setVal == ''){ $style = $type.':'.$val.';'; }else{ $style = $type.':'.$setVal.';'; } return $style; }  function imgsize($size,$setsize='400'){ if($size == ''){$size = $setsize;} $imgsize = array(16,20,24,30,32,36,40,48,60,64,70,72,80,90,100,110,120,128,130,145,160,170,190,200,210,220,230,240,250,290,300,310,320,350,360,400,430,460,480,540,560,570,670);  if($size > $imgsize[count($imgsize)-1]){ return $imgsize[count($imgsize)-1]; }else{ for ($i = 0; $i < count($imgsize); $i++) { if($imgsize[$i] >= $size){ return $imgsize[$i]; $i = count($imgsize); } } } }function get_holiday_url(){return $_MODULE['jrbq'];}function torf($play_name,$module){ $is_display = explode('@_@',$module); $play = in_array($play_name,$is_display)? true : false; return $play; } function haveAttr($attr,$value,$other=''){ if ($value) { return $attr.':'.$value.$other; } } function setBackground($value,$tof,$str=''){ if ($value) { $bac='background'; return $tof ? "$bac: url($value)".$str : "$bac:$value".$str ; } } function get_nr($module,$icon,$ele,$class=''){ $nr_arr = explode($icon,$module); $nr_str =''; foreach ($nr_arr as $nr){ $nr_str = $nr_str."<$ele class='$class'>$nr</$ele>"; } return $nr_str; } function make_Arr($str,$icon){ $arr=explode($icon,$str); return $arr; }   function marb(){ return $_MODULE['mar-b'] ? 'margin-bottom:'.$_MODULE['mar-b'].'px;' : ''; } function color($color){ return $_MODULE[$color] ? 'color:'.$_MODULE[$color].';' : ''; } function jb($icon,$zdy,$size){ if($_MODULE["$zdy"]){ return "background:url($zdy) no-repeat;"; } else if($_MODULE["$icon"]){ $icon = $_MODULE["$icon"] ; return "background:url(../../assets/images/$size"."jb/$icon.png) no-repeat;"; } } function ws($num,$ws){ return number_format($num,$ws,'.',''); } function ewm($m='e-code'){ return $ec = $_MODULE[$m] =='tc' ? 'tc' : ''; } function jgbq(){ return $ec = $_MODULE['jg-class'] =='jgtc' ? 'jgtc' : ''; } function mb($m='dtmb'){ $tp = $_MODULE[$m]; return "../../assets/images/zz/$tp.gif"; } function bk(){ return $_MODULE['bk'] =='dt' ? 'dt' : ''; } function djs(){ return $_MODULE['djstx'] =='dtc' ? 'dtc' : ''; } function tof($play_name,$model='tof'){ $is_display = explode('@_@',$_MODULE[$model]); $play = in_array($play_name,$is_display)? true : false; return $play; } function jrbq($m='jrbq'){ $bq = $_MODULE["$m"] == 'zd' ? get_holiday_url() : $_MODULE["$m"]; return  "../../assets/images/cx/$bq.png"; } function bh($n,$m='bh'){ $height = explode(',',$_MODULE["$m"])[$n]; return $height ? "height:$height".'px;' :''; } function ys($m){ if($_MODULE["$m"]){ return "color:".$_MODULE["$m"].';'; } } function btlb($n,$m1='timgurl',$m2="mcolor1"){ $tb = explode(',',$_MODULE[$m1]); $re = ''; if($tb[$n]){ $re = setBackground($tb[$n],true,' no-repeat 50% 0;'); } else if($_MODULE[$m2]){ $re = setBackground($_MODULE[$m2],false,';'); } return $re; } function mr($m="purl"){ return $_MODULE[$m]; } function fm($n,$m="prurl"){ $url = explode(',',$_MODULE[$m]); if($url[$n]){ return $url[$n]; } else if($url[0]){ return $url[0];}}function jb1($icon,$zdy,$n,$size,$wh="jbsize"){ if($_MODULE["$zdy"]){ $i = explode(',',$_MODULE["$zdy"]); $src = "$i[$n]"; } else if($_MODULE["$icon"]){ $icon = $_MODULE["$icon"] ; $src = "../../assets/images/$size"."jb/$icon.png"; } $size = explode(',',$_MODULE[$wh]); $w = $size[0] ? "width="."$size[0]":''; $h = $size[1] ? "height="."$size[1]" :''; $jb = array(); $jb['src'] = $src ; $jb['w'] = $w ; $jb['h'] = $h ; return $jb ; } function barr($n=0,$m){ $arr = explode(',',$_MODULE["$m"]); return $arr[$n] ? "background:$arr[$n];" : ''; } function custom($m = 'custom'){ $arr = explode(',',$_MODULE[$m]); $num = $arr[0]-1; $arr[0] = $arr[0] ? "model$arr[0]" : ''; $arr1 = $arr[1]; $arr[1] = $arr1==='cfx' ? $arr[1] : 'zfx'; $arr[2] = $arr1==='cfx' ? ' '.$arr[0].'1' : ''; $arr[3] = $num; return $arr;}function skuImg($idList,$imgSize = '30'){  global $itemManager; $openItemDOList= $itemManager->queryByIds($idList,''); $skuLists = $itemManager->queryOpenSkuDOListByOpenItemDOList($openItemDOList);  foreach($skuLists as $skuList){  $urlArr [] =  $itemManager->getSkuPropertyPics($skuList,"$imgSize");}return $urlArr;}function getErcode($erId, $widthHeight = "90", $type = "1") { switch($type){ case 1: $code = 'type=ci&item_id='.$erId.'&v=1'; break; case 2: $code = 'v=1&type=bi&item_id='.$erId; break; case 3: $code = 'type=cs&shop_id='.$erId.'&v=1'; break; case 4: $code = 'v=1&type=bs&shop_id='.$erId; break; case 5: $code = 'type=we&we_id='.$erId.'&v=1'; break; default: $code = 'type=ci&item_id='.$erId.'&v=1'; } $imgsrc = 'http://gqrcode.alicdn.com/img?'.$code.'&w='.$widthHeight.'&h='.$widthHeight; return $imgsrc; }  function getFav($favText, $favItemid, $favData, $favClass = "qzzfav"){ global $uriManager; if($favData == 'shop'){ $sc_url = $uriManager->favoriteLink(); $sc_title = "����ղر�����"; }elseif($favData == 'item'){ $sc_url = "http://favorite.taobao.com/popup/add_collection.htm?id=".$favItemid."&itemtype=1&scjjc=1"; $sc_title = "����ղ��������"; } $sc = '<a class="J_TokenSign '.$favClass.'" title="'.$sc_title.'" href="'.$sc_url.'" target="_blank">'.$favText.'</a>'; return $sc; }  function getSizes(){ $tbSizes = array( 16,20,24,30,32,36,40,48,50,60,64,70,72,80,88,90,100,110,120,125,128,130,145,160,170,180,190,200,210,220,230,234, 240,250,270,290,300,310,315,320,336,350,360,400,430,460,468,480,490,540,560,570,580,600,640,670,720,728,760,960,970 ); return $tbSizes; } function getImg($img){ $arraySize = getSizes(); $newArray = array(); foreach($arraySize as $size){ if($size>=$img){ $newArray[] = $size; } } $itemPic = $img>970?"970":min($newArray); return $itemPic; } function discountPrice($item){ if($item->discountPrice || $item->discountPrice!=$item->price) { $discountPrice = number_format($item->discountPrice,3,".",""); }else{ $discountPrice = number_format($item->price,3,".",""); } return $discountPrice; } function getItems($ids, $categoryId, $keyword, $sortType = " ", $num = "20", $itemData = "1", $idsType= "itemForm") {global $itemManager, $uriManager, $rateManager; $arraySize = getSizes(); $itemsObj = array(); $ratesObj = array(); if($ids!=null && $itemData == 2){ if($idsType == 'itemRateForm'){ $itemRates = $rateManager->parse($ids); foreach($itemRates->keySet() as $id){ $itemsObj[] = $itemManager->queryById($id); $ratesObj[] = $itemRates->get($id); } }else{ $arrayIds = is_string($ids) ? explode(',', $ids) : (array) $ids; if($sortType == " "){ foreach($arrayIds as $id){ $itemsObj[] = $itemManager->queryById($id); } }else{ $itemsObj = $itemManager->queryByIds($arrayIds,$sortType); } } }elseif($categoryId!=null && $itemData == 3){ $jsonArray = json_decode($categoryId); foreach($jsonArray as $jsonObject){ $childIds = explode(",",$jsonObject->{childIds}); if($jsonObject->{childIds} != null){ foreach($childIds as $childId){ $items_xfl = $itemManager->queryByCategory($childId,$sortType,$num); foreach($items_xfl as $itemCate){ $itemsObj[] = $itemCate!=null ? $itemCate : ""; } } }else{ $items_dfl = $itemManager->queryByCategory($jsonObject->{rid},$sortType,$num); foreach($items_dfl as $itemCate){ $itemsObj[] = $itemCate!=null ? $itemCate : ""; } } } }elseif($keyword!=null && $itemData == 4||$itemData == 1){ $kw = $itemData==1?" ":$keyword; $kwObj = $itemManager->queryByKeyword($kw,$sortType,$num);$newType = str_replace('__','','_'.$sortType); $newObj = $sortType==" "?$kwObj:array_reverse($itemManager->queryByKeyword($kw,$newType,$num)); $delObj = array_unique(array_merge($kwObj,$newObj)); $itemsObj = array_merge($delObj,$delObj,$delObj,$delObj,$delObj);}  $skuLists = $itemsObj!=null ? $itemManager->queryOpenSkuDOListByOpenItemDOList($itemsObj) : ""; $itemData = $itemsObj!=null ? $itemData : "5"; $items = array(); if($itemData != 5 || $itemsObj!=null){$idArr=array();foreach ($itemsObj as $key => $item) { if($key<$num&&!in_array($item->id,$idArr)){$idArr[]=$item->id; if($item->exist){$qzz['url'] = $uriManager->detailURI($item); foreach($arraySize as $imgSize){ $qzz['pic'.$imgSize] = $item->getPicUrl($imgSize); } $qzz['title'] = $item->title; $qzz['price'] = $item->price; $qzz['discountPrice'] = discountPrice($item); $qzz['zhekou'] = number_format(str_replace(',','',discountPrice($item))/str_replace(',','',$item->price),2)*10; $qzz['soldCount'] = $item->soldCount; $qzz['collectedCount'] = $item->collectedCount; $qzz['id'] = $item->id; $qzz['commentCount'] = $item->commentCount;$qzz['pj'] =$uriManager->rateURI();$qzz['itemCategoryId'] = $item->itemCategoryId; $qzz['skuList'] = $skuLists[$key]; foreach($arraySize as $imgSize){ $qzz['skuPics'.$imgSize] = $itemManager->getSkuPropertyPics($skuLists[$key],$imgSize,$imgSize); } $qzz['rateList'] = $ratesObj[$key]!=null?$ratesObj[$key]:""; } }else{break;} $items['idA'][] = $qzz['id']; $items[] = $qzz; }} if($itemData == 5|| $items == null) { $imgUrl = array( "http://img02.taobaocdn.com/imgextra/i2/34251258/TB2Dc8mcVXXXXbHXpXXXXXXXXXX_!!34251258.jpg", "http://img02.taobaocdn.com/imgextra/i2/34251258/TB2Dc8mcVXXXXbHXpXXXXXXXXXX_!!34251258.jpg" ); for ($i = 0; $i < $num; $i++){ $mtRand = mt_rand(0,(count($imgUrl)-1)); $qzz['url'] = "http://www.taobao.com/?id=www.qiaozhezou.com";foreach($arraySize as $imgSize){$qzz['pic'.$imgSize]=$imgUrl[$mtRand]."_".$imgSize."x".$imgSize.".jpg"; }$qzz['title']="��������δ���ӣ��������Ͻǵı༭��ťѡ���������ı���";$qzz['price']="0.00";$qzz['discountPrice']="00.00";$qzz['zhekou']=number_format(398.98/598.00,2)*10;$qzz['soldCount']="0";$qzz['collectedCount']="0";$qzz['id']="1".$i;$qzz['itemCategoryId']="2".$i;$qzz['no']=true;$items[]=$qzz;}$items[]='';} return $items;}?>
<!--common_separator_local-->
<div class="tb-module tshop-um tshop-um-c-Service990" style="<?= haveAttr('margin-bottom',$_MODULE['mar-b'],'px;')?>">
<?php if ($_MODULE['html']) {echo $_MODULE['html'];} else {if ($_MODULE['service']==1){?>
    <div class="section1 m-b20">
        <div class="gz-xx">
            <?php if ($_MODULE['serviceinfo']) {foreach (make_Arr($_MODULE['serviceinfo'],"\n") as $item) {?><p><?=$item?></p><?php}} else { ?>
            <p>
                <span class="hyy">��ӭ���Ϲ˿͹��ٱ���</span><span class="gz-sj">����ʱ�� :������09:00 - PM23:00</span>
            </p><p class="gz-sm">Ϊ�˱�֤���õķ���...</p><?php}?><a href="<?=$uriManager-> favoriteLink();?>" class="sc"></a>
        </div>
        <div class="kf">
            <div class="icon"><i></i><span><?=$_MODULE['title-name']?></span></div>
            <?php if ($_MODULE['ispre']) {?>
                <div class="kf1 sq">
                    <span  class="title"><?=$_MODULE['pre-sale-title']?></span>
<ul>
<?php$sqnc = explode(',',$_MODULE['pre-name']);$sqzh = explode(',',$_MODULE['pre-user']);$shnc = explode(',',$_MODULE['aft-name']);$shzh = explode(',',$_MODULE['aft-user']);$zsm = $_MODULE['c-service-info'] == 'b' ? 1 :2 ;$ftp = $_MODULE['c-service-info'] == 'p' ? 'sb': 'bsb' ;
if ($_MODULE['c-service-info'] != 'p' ) {$ysm = 'bi';if($_MODULE['c-service-info'] != 'b'){$ysm = 'si' ;}}for($i=0;$i<count(make_Arr($_MODULE['pre-url'],','));$i++){?>
<li class="<?=$ftp?>"><div class="zrtx <?=$ysm?>"><div class="iconx"><? if ($_MODULE['c-service-info'] == 'p') {$hover = $_MODULE['iconeffect']; ?><img src="<?=make_Arr($_MODULE['pre-url'],',')[$i]?>" alt=""><?}?><div  class="iconn <?=$hover?>"><?= $uriManager->supportTag($sqzh[$i],'���ֱ�ӷ���',$zsm);?></div></div><p><?=make_Arr($_MODULE['pre-name'],',')[$i]?></p></div></li><?php}?></ul>
</div><?php}?>
<div class="kf1 sh"><span class="title"><?=$_MODULE['aft-sale-title']?></span><ul><?php for($i=0;$i<count(make_Arr($_MODULE['aft-url'],','));$i++){?><li class="<?=$ftp?>"><div class="zrtx <?=$ysm?>"><div class="iconx"><? if ($_MODULE['c-service-info'] == 'p') {?><img src="<?=make_Arr($_MODULE['aft-url'],',')[$i]?>" alt=""><?}?><div  class="iconn <?=$hover?>"><?= $uriManager->supportTag($shzh[$i],'���ֱ�ӷ���',$zsm);?></div></div><p><?=make_Arr($_MODULE['aft-name'],',')[$i]?></p></div></li><?php}?></ul></div></div>
<div class="wb"><p class="left"><?=$_MODULE['other-content1']?></p><p class="right"><?=$_MODULE['other-content2']?></p></div>
</div>
<?php } else if ($_MODULE['service']==2){?>
<div class="section2 m-b20">
<?php?>
<?php?>
<div class="main">
<?php if($_MODULE['title-name2']){?>
<span class="zx-kf"><?=$_MODULE['title-name2']?></span>
<?php}?>
<div class="nr">
<div class="xs">
<?php if($_MODULE['pre-sale-name2']){?><span class="up"><?=$_MODULE['pre-sale-name2']?></span><?php}?>
<?php if($_MODULE['aft-sale-name2']){?><span><?=$_MODULE['aft-sale-name2']?></span><?php}?>
</div>
<div class="icon">
<?php if (torf('pre',$_MODULE['t-o-f'])) {?>
<ul class="sq">
<?php
$sqnc = explode(',',$_MODULE['pre-name1']);
$sqzh = explode(',',$_MODULE['pre-user1']);
$shnc = explode(',',$_MODULE['aft-name1']);
$shzh = explode(',',$_MODULE['aft-user1']);
$qm = $_MODULE['pre-icon1'] ? 2 : 1;
$hm = $_MODULE['next-icon1'] ? 2 : 1;
for ($i=0;$i<10;$i++){
?>
<li class="<?=$_MODULE['pre-icon1']?>">
<?= $uriManager->supportTag($sqzh[$i],'���ֱ�ӷ���',$qm);?>
<p><?=$sqnc[$i]?></p></li><?php}?></ul><?php}?><div class="down"><?php if (torf('aft',$_MODULE['t-o-f'])) {?><ul class="sh">
<?php for ($i=0;$i<3;$i++){?>
<li class="<?=$_MODULE['next-icon1']?>">
<?= $uriManager->supportTag($shzh[$i],'���ֱ�ӷ���',$hm);?>
<p><?=$shnc[$i]?></p></li><?php}?></ul><?php}?><ul class="fw-xx">
<?php if (torf('time',$_MODULE['t-o-f'])) { ?><li><span><?=$_MODULE['otitle']?></span><?php if ($_MODULE['othernr2']) {echo $_MODULE['othernr2']; ?>
<?php} else {?><div><p>09:00 - 23:00</p><p>�������ղ���Ϣ</p>
</div><?php}?></li><?php}?><?php if (torf('phone',$_MODULE['t-o-f'])) {?>
    <li><span><?=$_MODULE['antitle']?></span><?php if ($_MODULE['gg2']) {echo $_MODULE['gg2']; ?>
<?php} else {?><div><p>XXX-XXX-XXX-XX</p><p>��ӭ���Ϲ˿͹��ٱ���</p></div><?php}?></li><?php}?>
</ul></div></div></div></div>
</div>
<?php } else if ($_MODULE['service']==3) {?>
    <div class="section3 m-b20">
        <img src="assets/images/kf03/kfbg03.png" width="990" height="118" alt="" class="bg-img">
        <div class="main kf">
            <div class="left kf1">
                <p class="title"><?=$_MODULE['pre-sale-name3']?></p>
                <ul>
                    <?php
                    $qicon3 = explode(',',$_MODULE['pre-user3']);
                    for($i=0;$i<count(make_Arr($_MODULE['pre-url3'],','));$i++){
                        ?>
                        <li class="">
                            <div class="zrtx">
                                <div class="iconx">
                                    <img src="<?=make_Arr($_MODULE['pre-url3'],',')[$i]?>" alt=""  width="45" height="45" >
                                    <div class="iconn <?=$_MODULE['icon-effect3']?>">
                                        <?= $uriManager->supportTag($qicon3[$i],'���ֱ�ӷ���',2);?>
                                    </div>
                                </div>
                                <p><?=make_Arr($_MODULE['pre-name3'],',')[$i]?></p>
                            </div>
                        </li>
                    <?php}?>
                </ul>
            </div>
            <div class="right kf1">
                <p class="title"><?=$_MODULE['aft-sale-name3']?></p>
                <ul>
                    <?php
                    $hicon3 = explode(',',$_MODULE['aft-user3']);
                    for($i=0;$i<count(make_Arr($_MODULE['aft-url3'],','));$i++){
                        ?>
                        <li class="">
                            <div class="zrtx">
                                <div class="iconx">
                                    <img src="<?=make_Arr($_MODULE['aft-url3'],',')[$i]?>" alt=""  width="45" height="45" >
                                    <div class="iconn <?=$_MODULE['icon-effect3']?>">
                                        <?= $uriManager->supportTag($hicon3[$i],'���ֱ�ӷ���',2);?>
                                    </div>
                                </div>
                                <p><?=make_Arr($_MODULE['aft-name3'],',')[$i]?></p>
                            </div>
                        </li>
                    <?php}?>
                </ul>
            </div>
        </div>
    </div>
<?php } else {?>
    <div class="section4">
        <i class="bg"></i>
        <div class="main">
            <div class="up">
                <div class="img">
                    <img src="assets/images/kf04/ww.png" width="66" height="83" alt="" class="bicon <?=$_MODULE['dec-mouseover']?>">
                </div>
                <ul class="kf">
                    <?php foreach (make_Arr($_MODULE['pre-url4'],',') as $url){?>
                        <li>
                           <img src="<?=$url?>" width="70" height="70" alt=""  class="bicon <?=$_MODULE['dec-mouseover']?>">
                        </li>
                    <?php}?>
                </ul>
            </div>
            <div class="down">
                <div class="left">
                    <p class="kf-zx"><?=$_MODULE['04-big-title']?></p>
                    <p class="yw"><?=$_MODULE['04-small-title']?></p>
                </div>
                <ul class="middle kf1">
                    <?php
                    $sqzh4 = explode(',',$_MODULE['pre-user4']);
                    $icon = $_MODULE['gz04'] ? 1 : 2 ;//��Сͼ���ж�
                    $small = !$_MODULE['gz04'] ? 'small' :'';
                    for($i=0;$i<count(make_Arr($_MODULE['pre-name4'],','));$i++){

                        ?>
                        <li class="sq4 <?=$small?>">
                            <div>
                                <?= $uriManager->supportTag($sqzh4[$i],'���ֱ�ӷ���',$icon);?>
                                <p><?=make_Arr($_MODULE['pre-name4'],',')[$i]?></p>
                            </div>
                        </li>
                    <?php}?>
                </ul>
                <div class="right">
                    <?php
                    if (preg_match('/[\/<>\'\'""]+/', $_MODULE['gg4'])) {
                        echo $_MODULE['gg4'];
                    } else {
                        preg_match_all('/^[^\s]*/gm',$_MODULE['gg4'],$gg4);
                        foreach ($gg4[0] as $item){
                        ?>
                        <p><?=$item?></p>
                    <?php}}?>

                </div>
            </div>
        </div>
    </div>
<?php }}?>
</div>
